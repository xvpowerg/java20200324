/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch15_20200514;
import java.util.function.Supplier;
import java.util.function.Consumer;
public class Ch15_2 {

    
    static void printCat(String name,Supplier<Cat> sup,Consumer<Cat> con){
	Cat cat =sup.get();
	cat.setName(name);
	con.accept(cat);
    }
    
    //Supplier 要提供Cat
    //Consumer 要將Cat的name轉為大寫 在set回Cat
    static Cat toUpperCaseName(String name,Supplier<Cat> sup,
			    Consumer<Cat> con)    
    {
	Cat cat =sup.get();
	cat.setName(name);
	con.accept(cat);
	return cat;
    }

    
    public static void main(String[] args) {
	// TODO code application logic here
	printCat("Kitty",Cat::new,
		(c)->System.out.println(c));//希望印出cat的內容
	String st1 = "Kitty";
	
	Cat c2 = toUpperCaseName("Kitty",Cat::new,(c)->{
	   String name =  c.getName();
		name = name.toUpperCase();
	      c.setName(name);
	});
	System.out.println(c2);
    }
    
}
