/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch15_20200514.test_enum;

/**
 *
 * @author xvpow
 */
public class Ch15_7 {
    enum Skill{
	JAVA,C,GO,PYTHON
    }
    public static void main(String[] args) {
	Skill[] skills = Skill.values();
	for (Skill sk : skills){
	    System.out.println(sk);
	}
	Skill mySkill= Skill.valueOf("GO");
	System.out.println(mySkill);
	//因為沒有R所以會拋出例外
//	mySkill= Skill.valueOf("R");
//	System.out.println(mySkill);

    System.out.println(Skill.JAVA.name());
    System.out.println(Skill.JAVA.ordinal());
    System.out.println(Skill.C.ordinal());
    System.out.println(Skill.GO.ordinal());
    
   
    }
    
}

