/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch15_20200514.test_enum;

/**
 *
 * @author xvpow
 */
public class Ch15_6  {
    //建立了一個Animal的列舉類別
    //使用Animal建一個屬性name為DOG的enum物件
    //使用Animal建一個屬性name為CAT的enum物件
    //使用Animal建一個屬性name為TIGER的enum物件
    enum Animal{
	DOG,CAT,TIGER
    }
    static void selectAnimal(Animal animal){
	switch(animal){
	    case DOG:
		System.out.println("汪汪!");
		break;
	    case CAT:
		System.out.println("喵喵");
		break;
	    case TIGER:
		System.out.println("吼!!!");
		break; 
	}
    }
    public static void main(String[] args) {
	selectAnimal(Animal.CAT);
	//Animal.CAT 是不是屬於Animal這個類別
	System.out.println(Animal.CAT instanceof Animal);
	//證明CAT是一個物件
	Object obj = Animal.CAT;
	System.out.println(Animal.CAT.name());
	
	
    }
    
}
