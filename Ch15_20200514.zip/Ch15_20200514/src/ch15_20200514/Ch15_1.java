/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch15_20200514;
import java.util.function.Supplier;
public class Ch15_1 {
    
    static Person fetchPerson(Supplier<Person> sp,String name){
	Person p = sp.get();
	p.setName(name);
	return p;
    }
    
    static class MySupplier implements Supplier<Person>{
	public Person get(){
	    return new Person();
	}
    }
    
    public static void main(String[] args) {
//	Person p1 = new Person("Ken");
//	System.out.println(p1);
	Person p2 = fetchPerson(()->new Person(),"Vivin");
	System.out.println(p2);
	//Person::new 在編譯時會幫你把程式碼改為()->new Person()
	Person p3 = fetchPerson(Person::new,"Join");
	System.out.println(p3);
    }
}
