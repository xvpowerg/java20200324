/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch15_20200514;
import java.util.function.Predicate;
import java.util.function.Consumer;
/**
 *
 * @author xvpow
 */
public class Ch15_4 {

     static void filterNames(Predicate<String> p,String... names){
	for (String name : names){
	     if (p.test(name)){
		 System.out.println(name);
	      }
	}
     }
     //Predicate name長度>3條就成立
     //Consumer 幫我把字串轉成大寫並且印出
      static void filterNamesToUp(Predicate<String> p,Consumer<String> com,String... names){
	 for (String name :names){
	     if (p.test(name)){
		 com.accept(name);
	     }
	 }
      }
    public static void main(String[] args) {
	filterNames(n->n.length() >3,
		"Join","Tom","Vivin","Ken","Lucy");
	
	filterNamesToUp(n->n.length() > 3,n->{
	    System.out.println(n.toUpperCase());
	},"Join","Tom","Vivin","Ken","Lucy");
    }
    
}
