/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch15_20200514;

/**
 *
 * @author xvpow
 */
public class Person {
    private String name;
    Person(){}
    Person(String name){
	this.name = name;
    }
    public void setName(String name){
	this.name = name;
    }
    public String getName(){
	return this.name;
    }
    public String toString(){
	return getName();
    }
}
