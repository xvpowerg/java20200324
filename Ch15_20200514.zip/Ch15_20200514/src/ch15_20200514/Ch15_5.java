/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch15_20200514;
import java.util.function.UnaryOperator;
public class Ch15_5 {
    static void pluseArray(int[] number,UnaryOperator<Integer> op){	
	for (int i =0; i < number.length;i++){
	    number[i] = op.apply(number[i]);
	}
    }
    public static void main(String[] args) {
	int[] array = new int[]{7,2,9,3};
	pluseArray(array,n->{return n+5;});
	for(int v:array){
	    System.out.println(v);
	} 
    }
    
}
