/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch15_20200514;
import java.util.function.Function;
/**
 *
 * @author xvpow
 */
public class Ch15_3 {
    //把一個字串轉為Person
    //Function<String,Person> 把字串轉換為person
    public static Person createPerson(String name,Function<String,Person> f){
	return f.apply(name);
    }
    public static void main(String[] args) {
	// TODO code application logic here
	Person p1 = 
	    createPerson("Lindy",(n)->new Person(n));
	System.out.println(p1);
    }
    
}
