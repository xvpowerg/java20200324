/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch15_20200514.time;
import java.util.Calendar;
import java.time.LocalTime;
public class Ch15_8 {

    public static void main(String[] args) {
	Calendar caldnder =  Calendar.getInstance();
	System.out.println(caldnder.get(Calendar.HOUR_OF_DAY)+":"+
		caldnder.get(Calendar.MINUTE)+":"+
		caldnder.get(Calendar.SECOND));
	//LocalTime  不能new
	LocalTime localTime = LocalTime.now();
	System.out.println(localTime.getHour()+":"+
		localTime.getMinute()+":"+
		localTime.getSecond());
	
    }
    
}
