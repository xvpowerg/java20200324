/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20200505.functional;

//Functional interface
//interface 介面內抽象方法只有一個
//java 8 才有的
@FunctionalInterface
//FunctionalInterface 介面模擬方法
//1個FunctionalInterface  表示一個方法
public interface TestFunctional {
    public void myfunction();
}
