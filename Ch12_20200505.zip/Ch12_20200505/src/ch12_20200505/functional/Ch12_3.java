/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20200505.functional;

public class Ch12_3 {

    //java內建FunctionalInterface
    //Consumer<T>   void accept(T t) 只傳入數值
    //Function<T,R> R	apply(T t)  可傳入數值與回傳
    //Predicate<T>  boolean test(T t) 回傳Boolean
    //Supplier<T>  T Supplier() 只回傳東西
    //UnaryOperator<T> T apply(T t) 傳入跟回傳的類型一樣
    public static void main(String[] args) {
	  
    }
    
}
