/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20200505.shadow;

/**
 *
 * @author xvpow
 */
public class Ch12_6 {
    //靜態看類別
    //非靜態看物件
    //靜態共享
    //非靜態是獨立
    public static void main(String[] args) {
	
	TestStatic ts1 = new TestStatic();
	TestStatic ts2 = new TestStatic();
	System.out.println(ts1.value1);
	System.out.println(ts2.value1);
	System.out.println("==============");
	ts1.value1 = 75;
	System.out.println("ts1:"+ts1.value1);
	System.out.println("ts2:"+ts2.value1);
    System.out.println("======Static========");
        System.out.println("ts1:"+ts1.value2);
	System.out.println("ts2:"+ts2.value2);
	ts2.value2 = 98;//共享 考試愛考這樣的寫法
	TestStatic.value2 = 98;//因該這樣做
	  System.out.println("ts1:"+ts1.value2);
	  System.out.println("ts2:"+ts2.value2);
	   System.out.println("ts2:"+TestStatic.value2);//因該這樣做
	  
	  

    }
    
}
