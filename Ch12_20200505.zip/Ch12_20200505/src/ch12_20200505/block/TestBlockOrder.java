/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20200505.block;

/**
 *
 * @author xvpow
 */
public class TestBlockOrder {
    static int value = 10;
    {
       System.out.println("For Object 1");
    }
    static {
      System.out.println("static 1");
    }
    
    public TestBlockOrder(){
	 System.out.println("TestBlockOrder()");
    }
    static {
      System.out.println("static 2");
    }
  
    {
       System.out.println("For Object 2");
    }
}
