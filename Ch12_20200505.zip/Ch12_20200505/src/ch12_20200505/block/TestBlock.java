/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20200505.block;

//
public class TestBlock {
   int[] numbers = new int[500];
   //每個建構子都需要呼叫的程式碼 可以放在區塊內

   TestBlock(int value){
   }
   
  TestBlock(){}
        {
	     for (int i = 0; i < numbers.length;i++){
		numbers[i] = -1;
	    }
	    
	}
}
