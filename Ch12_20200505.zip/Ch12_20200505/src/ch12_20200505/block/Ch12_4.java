/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20200505.block;

/**
 *
 * @author xvpow
 */
public class Ch12_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	TestBlock tb = new TestBlock();
	System.out.println(tb.numbers[5]);
	TestBlock tb2 = new TestBlock(51);
	System.out.println(tb2.numbers[5]);
	System.out.println("===================");
//	TestStaticBlock tsb = new TestStaticBlock();
//	System.out.println(tsb.numbers[5]);

System.out.println(TestStaticBlock.numbers[5]);
	
    }
    
}
