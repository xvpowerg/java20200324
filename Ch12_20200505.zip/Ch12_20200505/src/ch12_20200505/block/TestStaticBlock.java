/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20200505.block;

/**
 *
 * @author xvpow
 */
public class TestStaticBlock {
      static int[] numbers = new int[500];
      static{
	     for (int i = 0; i < numbers.length;i++){
		numbers[i] = -1;
	    }
	}
      public TestStaticBlock(){
	  
      }
}
