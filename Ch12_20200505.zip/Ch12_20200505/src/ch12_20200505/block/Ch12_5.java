/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20200505.block;

/**
 *
 * @author xvpow
 */
public class Ch12_5 {
//區塊的順序
 // 靜態區塊  非靜態區塊  建構子
//靜態區塊 類別載入時呼叫 只會呼叫一次
//非靜態區塊 new 時呼叫 可呼叫多次
    
    public static void main(String[] args) {
	//類別載入時會執行static block
	TestBlockOrder.value = 10;
	new TestBlockOrder();
	new TestBlockOrder();
//	TestBlockOrder tb1 = new TestBlockOrder();
//	TestBlockOrder tb2 = new TestBlockOrder();
	
	
    }
    
}
