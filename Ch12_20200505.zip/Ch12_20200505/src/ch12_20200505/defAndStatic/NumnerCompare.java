/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20200505.defAndStatic;

/**
 *
 * @author xvpow
 */
public class NumnerCompare implements MyCompare{
    public int compara(Number a,Number b){
	 if (a.doubleValue() > b.doubleValue()){
	     return 1;
	 }else if(a.doubleValue() < b.doubleValue()){
	     return -1;   
	 }
	return 0;
    }
}
