/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20200505.defAndStatic;

/**
 *
 * @author xvpow
 */
public interface MyCompare {
    //假設定義
    // a 大於b return 正數
    // a 小於b return 負數
   // a 等於b return  零
    int compara(Number a,Number b);
    //靜態方法不會被繼承
    static Number max(MyCompare myCompare,Number a,Number b){
	Number max = a;
	if (myCompare.compara(a, b) < 0){
	    max = b;
	}
	return max;
    }
    static Number min(MyCompare myCompare,Number a,Number b){
	Number min = a;
	if (myCompare.compara(a, b) > 0) min = b;
	return min;
    }
}
