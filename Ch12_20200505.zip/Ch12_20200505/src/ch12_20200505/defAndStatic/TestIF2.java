/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20200505.defAndStatic;

/**
 *
 * @author xvpow
 */
public interface TestIF2 extends TestIF1 {
     default void  myDef(){
	System.out.println("TestIF2");
    }
      static void testStatic(){
	System.out.println("TestIF2 testStatic");
    }
}
