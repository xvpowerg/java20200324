/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20200505.defAndStatic;


//討論TestIF1 與 TestIF2 有相同Default方法
//TestIF3 又繼承了TestIF1 與 TestIF2 這時 會發生錯誤
//因為TestIF3 不知道該讀取哪個Default方法
//1 可將TestIF1 與 TestIF2 重複的Default方法移除其1
//2 可在TestIF3 內覆寫default方法
//3 TestIF2 繼承 TestIF1 
public class Ch12_1 implements TestIF3 {
    public static void main(String[] args) {
	Ch12_1 ch121 = new Ch12_1();
	ch121.myDef();
	//錯誤
	//ch121.testStatic();
		
    }
}
