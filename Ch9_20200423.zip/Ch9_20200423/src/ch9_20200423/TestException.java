/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20200423;
import java.io.IOException;
import java.io.FileNotFoundException;
public class TestException {
    //throws IOException 意思可能拋出IOException
     public void catchException(int value)
	     throws IOException,FileNotFoundException{	   
	System.out.println("catchException 1");
	 if (value == 10){
	  throw new IOException();  
	}
	System.out.println("catchException 2");
     }
}
