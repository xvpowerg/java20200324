/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20200423;

/**
 *
 * @author xvpow
 */
public class TestOverrideSub1  extends TestOverride{
    //只能是public覆寫
      public void testPublic(){
	System.out.println("testPublic!!! Sub");
    }
	//可以是 protected public 覆寫
       protected void testProtected(){
	System.out.println("testProtected!!! Sub");
    } 
       //可以是 default protected public 覆寫
      void testDefault(){
	System.out.println("testDefault!!! Sub");
    }
      //private 他不是覆寫  他是一個新方法
     private  int testPrivate(){
	System.out.println("testPrivate!!! Sub");
       return 10;
     }
     
       //2 回傳值 回傳型態若為基本型 必須一模一樣
    public int testReturn(){
	return 20;
    }
    
    // 3回傳值 回傳型態若為參考型態 可一樣或子類
    //回傳類型 可以是 Animal Dog  Cat
    public Cat testReturnRef(){
	System.out.println("testReturnRef Cat");
	return null;
    }
    //不會錯 但不是正確覆寫
     public void testInput(Dog an){
	System.out.println("TestOverride  Dog");
    }
 
}
