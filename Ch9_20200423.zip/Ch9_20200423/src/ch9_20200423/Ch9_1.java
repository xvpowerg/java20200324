/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20200423;
public class Ch9_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	//探討覆寫(Override)規則
	//覆寫 討論 子類別如何覆蓋父類別的方法
	// 1 讀取權限只能公開不能封閉
	// 2 回傳值 回傳型態若為基本型 必須一模一樣
	// 3回傳值 回傳型態若為參考型態 可一樣或子類
	//4 方法名稱與傳入參數類型必須一樣 
	//5 例外拋出 可以一樣或子類或不拋出
	
	
	//讀取權限
	//public  最公開 可跨package 
	//protected 可在相同package讀取 或 繼承時的子類別內可讀取
	//default(空白的讀取權限) 只能在相同package 
	//private  最私密 只能在自己類別讀取
	
	TestScope ts = new TestScope();
	System.out.println(ts.defaultValue);
	System.out.println(ts.protectValue);
	System.out.println(ts.publicValue);
	
	
    }
    
}
