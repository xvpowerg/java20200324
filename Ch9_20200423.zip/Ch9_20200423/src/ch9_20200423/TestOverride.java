/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20200423;

/**
 *
 * @author xvpow
 */
public class TestOverride {
    public void testPublic(){
	System.out.println("testPublic!!!");
    }
    protected void testProtected(){
	System.out.println("testProtected!!!");
    }
    void testDefault(){
	System.out.println("testDefault!!!");
    }
    private void testPrivate(){
	System.out.println("testPrivate!!!");
    }
    
    //2 回傳值 回傳型態若為基本型 必須一模一樣
    public int testReturn(){
	return 10;
    }
    
    // 3回傳值 回傳型態若為參考型態 可一樣或子類
    public Animal testReturnRef(){
	System.out.println("testReturnRef Animal");
	return null;
    }
    public void testInput(Animal an){
	System.out.println("TestOverride Animal");
    }
}
