/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20200423.other;

import ch9_20200423.*;

/**
 *
 * @author xvpow
 */
public class TestOverrideSub2  extends TestOverride{
    //只能是public覆寫
      public void testPublic(){
	System.out.println("testPublic!!! Sub");
    }
	//可以是 protected public 覆寫
       protected void testProtected(){
	System.out.println("testProtected!!! Sub");
    } 
       //因為跨package所以無法覆寫 所以是一個新方法
     private void testDefault(){
	System.out.println("testDefault!!! Sub");
    }
      //private 他不是覆寫  他是一個新方法
     private  int testPrivate(){
	System.out.println("testPrivate!!! Sub");
       return 10;
     }
}
