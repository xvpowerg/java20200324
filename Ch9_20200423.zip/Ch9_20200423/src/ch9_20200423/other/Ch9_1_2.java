package ch9_20200423.other;
import ch9_20200423.TestScope;
public class Ch9_1_2 extends TestScope{
    public void testValue(){
	System.out.println(this.protectValue);
    }
    public static void main(String[] args) {
	//類別在不同Package時  時用前需要import 或 輸入全名
	//所有在java.lang下的類別使用前不需要import 或 輸入全名
	TestScope ts = new TestScope();
	ts.publicValue = "My Public!!";
	
	Ch9_1_2 c91 = new Ch9_1_2();
	c91.protectValue = 10;
	c91.testValue();
	
	
    }
}
