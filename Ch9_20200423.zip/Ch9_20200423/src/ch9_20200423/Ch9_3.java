/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20200423;
import java.io.FileNotFoundException;
import java.io.IOException;
public class Ch9_3 {

    public static void main(String[] args) throws IOException {
	//例外分兩種
	//1 必要例外檢測
	    // 網路斷線 壞軌 等等.....
	   //Exception  
	 //SQLException  IOException 是 FileNotFoundException 的父類別
	//2 非必要例外檢測
	   // 文字無法轉數字 Index過長或太短	  
	 // RuntimeException   
	   //ArithmeticException 算數學 2/0
	   //NullPointerException
	   //IndexOutOfBoundsException
	   
	   TestException texce = new TestException();
	   //例外的catch 父類別必須在下 子類別必須在上
	   try{
	       System.out.println(" try 1");
	       texce.catchException(10);
	       System.out.println(" try 2");
	   }catch(FileNotFoundException ex){
	         System.out.println("FileNotFoundException:"+ex);
	   }
	   catch(IOException ex){
	       //可在此處理例外
	       System.out.println("IOException:"+ex);
	   }
	   System.out.println("Test 1");
	   texce.catchException(10);
	  System.out.println("Test 2");
	   
    }
    
}
