/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch25_20200618;

import java.io.IOException;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.PathMatcher;
import java.nio.file.Paths;
import java.util.stream.Stream;

public class Ch25_3 {
    public static void main(String[] args)throws IOException {
	Path path = Paths.get("c:","mydir");
	 Stream<Path>  pathsStream3 = Files.walk(path, 3);
	 //getDefault() 取得一個預設 FileSystem 
	 FileSystem  fsys = FileSystems.getDefault();
	 
	 // /**不管有多少目錄都可滿足
	 // /* 不管目錄名稱是什麼
	 PathMatcher pm = fsys.getPathMatcher("glob:C:/**/*.zip");
//	 Path testPath = Paths.get("C:","mydir","test_copy.zip");
//	System.out.println(pm.matches(testPath));
//	 pathsStream3.filter(p->{
//		return pm.matches(p);
//	 }).forEach(System.out::println);
	
	 //{zip,data} 附檔名是 zip 或 data
//	  PathMatcher pm2 = fsys.getPathMatcher("glob:C:/**/*.{zip,data}");
//	 pathsStream3.filter(p->{
//		return pm2.matches(p);
//	 }).forEach(System.out::println);
	 
	 //[!a-z] 不是 a到z的目錄把它顯示出來
	   PathMatcher pm3 = fsys.getPathMatcher("glob:C:/**/*[!a-z]");
	 pathsStream3.filter(p->{
		return pm3.matches(p);
	 }).forEach(System.out::println);
    }
    
}
