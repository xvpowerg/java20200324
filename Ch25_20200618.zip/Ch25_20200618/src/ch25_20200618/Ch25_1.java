/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch25_20200618;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.io.IOException;
import java.util.List;
import java.util.stream.Stream;
public class Ch25_1 {

    public static void main(String[] args) {
	//寫文字檔
	Path path = Paths.get("c:","mydir","testWrite.txt");
	String msg = "任天堂(Nintendo)與寶可夢公司(The Pokémon Company) \n"
		+ "透過 6 月 17 日的「Pokémon Presents」發表會公布了多款遊戲新作，\n"
		+ "帶動任天堂的股價在週三創下新高點。無論你是手機用戶，\n"
		+ "還是 Switch 玩家，或是支持任天堂多年的死忠粉絲，\n"
		+ "本次的更新亮點都可望讓你心得滿足。";
	try{
	    Files.write(path,msg.getBytes());
	    	//讀文字檔
	     //List<String> strList =  Files.readAllLines(path);
	     //strList.forEach(System.out::println);
	     	//讀文字檔
	   Stream<String> strStream = Files.lines(path);
	   strStream.forEach(System.out::println);
	   //Files.list(path)
	}catch(IOException ex){
	    System.out.println(ex);
	}

	
    }
    
}
