/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch25_20200618;

/**
 *
 * @author xvpow
 */
public class Ch25_5 {
    static class MyNumber{
	 int x = 0;
	 private Object lock = this;
	 // synchronized 
	 //如果需求是一個Thread 完成後再執行另一個Thread 可把方法加上synchronized
//	public synchronized void add(){
//	    for (int i =1; i<=5;i++){		
//		x++;
//		System.out.println(x);
//	    }
//	}	
	 public  void add(){
	       System.out.println("Start:"+Thread.currentThread().getName());
	   synchronized(lock){
	         for (int i =1; i<=5;i++){	
		     System.out.println("Loop:"+Thread.currentThread().getName());     
		    x++;
		    System.out.println(x);
		}	     
	   }
	  System.out.println("End:"+Thread.currentThread().getName()); 
	}
    }
  //執行序搶佔問題
    // 1 共享某資源
    // 2 一定要一個以上的執行序
    public static void main(String[] args) {
	// TODO code application logic here
	MyNumber myNumber = new MyNumber();
	
	Thread th1 = new Thread(()->{
		myNumber.add();
	}  );
	th1.start();
	
	Thread th2 = new Thread(()->{
		myNumber.add();
	}  );
	th2.start();
	
    }
    
}
