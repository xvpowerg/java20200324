/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch25_20200618;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.io.IOException;
import java.util.List;
import java.util.stream.Stream;
/**
 *
 * @author xvpow
 */
public class Ch25_2 {

    public static void main(String[] args)throws IOException {
	//某資料夾下有那些檔案?
	Path path = Paths.get("c:","mydir");
	Stream<Path> pathsStream = Files.list(path);
	//pathsStream.forEach(System.out::println);
	//某資料夾下n層有那些檔案?
	//walk 預設情況下深度為2147483647
	 /*Stream<Path>  pathsStream2 = Files.walk(path);
	 pathsStream2.forEach(System.out::println);*/
	 // maxDepth = 0 為當前層次
	 //maxDepth 必須大於-1 小於2147483647
	 Stream<Path>  pathsStream3 = Files.walk(path, 3);
	  pathsStream3.forEach(System.out::println);
	 
    }
    
}
