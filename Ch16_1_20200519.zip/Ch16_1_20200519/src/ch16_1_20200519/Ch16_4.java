/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch16_1_20200519;
import java.util.List;
import java.util.ArrayList;
public class Ch16_4 {

    private static void printList(List<Integer> myList){
	System.out.println("===========================");
	myList.forEach(v->{
	System.out.print(v+" ");
	});
	System.out.println();
    }
    
    public static void main(String[] args) {
	List<Integer> list = new ArrayList<>();
	list.add(10);
	list.add(20);
	list.add(51);
	printList(list);
	list.add(2, 35);//插入的動作
	printList(list);
	//Set or List 都是一種 Collection 
	List<Integer> addList = new ArrayList<>();
	addList.add(71);
	addList.add(85);
	addList.add(22);
	list.addAll(addList);
	printList(list);
	//list.clear();
	//printList(list);
	boolean contains = list.contains(51);
	System.out.println("contains:"+contains);
	boolean contains2 = list.contains(103);
	System.out.println("contains2:"+contains2);
	int index = list.indexOf(85);
	System.out.println(index);
	index =  list.indexOf(103);//找不到回傳-1
	System.out.println(index);
	list.add(85);
	list.add(92);
	list.add(36);
	printList(list);
	System.out.println(list.lastIndexOf(85));
	
	list.remove(Integer.valueOf(10));
	printList(list);
	
	List<Integer> removeList = new ArrayList<>();
	removeList.add(51);
	removeList.add(85);
	
	list.removeAll(removeList);
	printList(list);
	//removeIf 方法內條件為true的會被移除
	list.removeIf(n->n%2!=0);
	printList(list);
	//對Ｌｉｓｔ內容作加2
	list.replaceAll(n->n +2);
	printList(list);
	list.set(1, 25);
	printList(list);
	list.sort((n1,n2)->n1-n2  );//預設都是遞增排序 小到大
	printList(list);
    }
    
}
