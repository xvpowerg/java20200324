/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20200416;

/**
 *
 * @author xvpow
 */
public class Animal {
    private String name;
    private int age;
    private float height;
    
    public Animal(){ }
    
    public Animal(String inName,int inAge,float inHeight){
	    name = inName;
	    age = inAge;
	    height = inHeight;
    }
    
    public String getName(){
	return name;
    }
    public void setName(String inName ){
	name = inName;
    }
    public int getAge(){
	return age;
    }
    public void setAge(int inAge){
	age = inAge;
    }
    public float getHeight(){
	return height;
    }
    public void setHeight(float inHeight){
	height = inHeight;
    }
    public void print(){
	System.out.println(getName()+":"+getAge()+":"+getHeight());
    }
}
