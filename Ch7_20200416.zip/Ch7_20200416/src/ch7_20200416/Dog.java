/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20200416;

/**
 *
 * @author xvpow
 */
//建構子不會被繼承
//私有的不會被繼承
//看不見的不會被繼承
public class Dog extends Animal{
    public Dog(){
	
    }
    public Dog(String inName,int inAge,float inHeight){
	//可以呼叫super() 來呼叫父類建構子
	//super() 只能在建構子內呼叫
	//必須是建構子內的第一組命令
	//this() 與　super()不可在同一個建構子內呼叫
	super(inName,inAge,inHeight);
	

    }
}
