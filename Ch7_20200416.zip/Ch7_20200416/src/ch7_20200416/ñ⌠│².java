/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20200416;

/**
 *
 * @author xvpow
 */
public class 水壺 {
    String 顏色;
    String 材質;
    private int 公升數;
    float 耐熱度;
    //Constructor 建構子
    //100% 考
    //口訣:沒有回傳值 名稱跟類別一樣的方法
    //建構子支持多載
    //預設建構子
     public 水壺(){
	 //this()
	 //只能在建構子呼叫 作用是我要呼叫目前類別其他的建構子
	 //this() 的位置只能是建構子的第一個命令
	this("顏色未設定","材質未設定",-1,-1);
	 System.out.println("水壺()");
//	 顏色 = "顏色未設定";
//	 材質 = "材質未設定";
//	 公升數 = -1;
//	 耐熱度 = -1;
     }
     //自定義建構子
      public 水壺(String c,String m,int ca,float h){
	  顏色 = c;
	  材質 = m;
	  公升數 = ca;
	  耐熱度 = h;
      }
    
    //寫入
    public void set公升數(int capacity){
	if (capacity <50 || capacity > 2000){
	    System.out.println("錯誤的容量!");
	    return;//離開方法
	}
	公升數 = capacity;
    }
   //讀取
    public int get公升數(){
	return 公升數;
    }
    
    public void printInfo(){
	System.out.println(顏色+":"+耐熱度+":"+公升數+":"+材質);
    }
}
