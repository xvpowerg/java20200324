/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20200416;

/**
 *
 * @author xvpow
 */
public class Ch7_1 {

    public static void main(String[] args) {
	// TODO code application logic here
	
	// 類別是一份訂單
	// 由類別這份訂單產生物件 
	
	//水壺
	//顏色:
	//材質:
	//公升數:
	//耐熱度:
	//只有new物件才會創造
	水壺 p;//p是一個變數可以放水壺這個物件
	p = new 水壺();//new 才是真的創造水壺這個物件
	p.顏色 = "";//作業:字串長度不可超過10 或 空白
	p.耐熱度=120f;
	//希望限制 必須封裝(encapsulation)
	//p.公升數 = 500;//50~2000
	p.set公升數(-500);
	p.材質 = "不鏽鋼";
	
	水壺 p2;
	p2 = new 水壺();
	p2.顏色 = "綠";
	p2.耐熱度 = 80f;
	p2.set公升數(100);
	p2.材質 ="PP";
	//每個物件有自己的記憶體空間 互不相影響
	System.out.println(p.顏色+":"+p.耐熱度+":"+
		p.get公升數()+":"+p.材質);
	p2.printInfo();
    }
    
}
