/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20200416;

/**
 *
 * @author xvpow
 */
public class Ch7_3 {

    public static void main(String[] args) {
	Dog dog1 = new Dog();
	dog1.setName("小白");
	dog1.setAge(2);
	dog1.setHeight(20);
	dog1.print();
	
	Dog dog2 = new Dog("大黃",3,50);
	dog2.print();
    }
    
}
