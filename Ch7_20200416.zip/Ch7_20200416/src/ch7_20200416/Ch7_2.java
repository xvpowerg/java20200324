/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20200416;

/**
 *
 * @author xvpow
 */
public class Ch7_2 {
    public static void main(String[] args) {
	
	//String c,String m,int ca,float h
	水壺 p3 = new 水壺("紅","汎合金",100,9000f);
	p3.printInfo();
	水壺 p4  = new 水壺();
	p4.printInfo();
	
    }
    
}
