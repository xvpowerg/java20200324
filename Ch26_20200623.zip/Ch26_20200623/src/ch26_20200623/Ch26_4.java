/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch26_20200623;

import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.Future;
import java.util.stream.Stream;
public class Ch26_4 {
    public static void main(String[] args) {
	ExecutorService fix = Executors.newFixedThreadPool(3);
  Future<Integer> f = fix.submit(()->{
	    System.out.println("正在產生數字中...");
		 try{
			TimeUnit.SECONDS.sleep(5);
		    }catch(Exception ex){
		    }   
	 return ThreadLocalRandom.current().nextInt(6000);
	});
	System.out.println("A.....");  
	fix.execute(()->{
	      try{ 
		 System.out.println(f.get());
	      }catch(Exception ex){      }
	});
	System.out.println("B.....");  
	fix.shutdown();	
	Stream.of("A","B","C").parallel();
    }
	//Fork-Join
        //使用工作竊取 演算法 平衡工作量
        //適用於數量大
        //需要做分解的動作Fork
	//需要做合併的動作Join
}
