/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch26_20200623;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
public class Ch26_3 {
    private static void testExecute(ExecutorService fix){
		fix.execute(()->{
	     System.out.println("Thread Name:"+Thread.currentThread().getName());	 
		    try{
			TimeUnit.SECONDS.sleep(2);
		    }catch(Exception ex){
		    }   
	    }); 
    }
    public static void main(String[] args) {
	ExecutorService fix = Executors.newFixedThreadPool(8);
	for (int i=1;i<=20;i++){
	    testExecute(fix);
	}
	fix.shutdown();
//	List list = fix.shutdownNow();
//	System.out.println(list.size());
	
    }
    
}
