/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch26_20200623;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
public class Ch26_2 {
    public static void main(String[] args){
	 ExecutorService es =   Executors.newCachedThreadPool();
	
	 for (int i =1;i<=50;i++){
	      es.execute(()->{
	     System.out.println("Thread Name:"+Thread.currentThread().getName());	 
		    try{
			TimeUnit.SECONDS.sleep(2);
		    }catch(Exception ex){

		    }   
		});
	 }
	//會等到ThreadPool的所有工作完成才會關閉ExecutorService
	// es.shutdown();
//	shutdownNow 回傳值 指的是 還沒進入ThreadPool的Runnable
//	shutdownNow 會立刻關閉ExecutorService
	List<Runnable> list = es.shutdownNow();
	System.out.println(list.size());
    }
    
}
