/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch26_20200623;

public class Ch26_1 {
    static class TestLock{
	public synchronized void test1(TestLock lock){
	    System.out.println("test1!!!");
	    lock.test2();
	}
	public synchronized void test2(){
	    System.out.println("test2!!");
	}
    }
   
    public static void main(String[] args) {
	TestLock tlock1 = new TestLock();
	TestLock tlock2 = new TestLock();
	//Main
	Thread th1 = new Thread(()->{
		tlock1.test1(tlock2);
	});
	Thread th2 = new Thread(()->{
		tlock2.test1(tlock1);
	});
	th1.start();
	th2.start();
    }
    
}
