/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch26_20200623;
//取得資料庫連線
import java.sql.DriverManager;
//資料庫連線
import java.sql.Connection;
//下達SQL指令
import java.sql.Statement;
//下達SQL指令是SELECT必須使用ResultSet 把資料輪巡
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;
public class Ch26_5 {
    public static void main(String[] args) {
	String url = "jdbc:derby://localhost:1527/mydatabase";
	String user = "qwer";
	String password = "12345";
	try(Connection conn =  DriverManager.getConnection(url, user, password);
	    Statement stm = conn.createStatement();
		) {
	    String insertSql =   "INSERT INTO STUDENT(id,name,height)"
			      + "VALUES(%d,'%s',%.2f)";
	    insertSql = String.format(insertSql,new Random().nextInt(10000),"Gigi",
		    151f);	    
	 int count =  stm.executeUpdate(insertSql);
            if(count > 0){
		    System.out.println("新增成功!");
		}			      
	    ResultSet res = stm.executeQuery("SELECT * FROM STUDENT");
	    while(res.next()){
		//開始index為1
		int id = res.getInt(1);
		String name = res.getString("name");
		double height =  res.getDouble(3);
		System.out.println(id+":"+name+":"+height);
	    }
	}catch(SQLException ex){
	    System.out.println(ex);
	}
	
    }
    
}
