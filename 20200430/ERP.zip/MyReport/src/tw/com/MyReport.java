/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com;
import tw.com.myerp.MyERP;
import java.util.List;
public class MyReport extends MyERP {
    protected void reportStyle(List<String> dataList){
	for (String value : dataList){
	    //split 把字串做分割 轉換成陣列
	    String[]  reportData =  value.split(",");
	    System.out.println(reportData[0]+":"+reportData[2]);
	}
    }

}
