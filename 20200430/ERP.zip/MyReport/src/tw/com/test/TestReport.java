/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.test;
import tw.com.myerp.MyERP;
import tw.com.MyReport;

public class TestReport {
    public static void main(String[] args) {
	
	MyERP erp = new MyReport();
	erp.export();
	
    }
    
}
