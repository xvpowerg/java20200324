package tw.com.myerp;
import java.util.List;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.io.IOException;
public abstract class MyERP {
        private List<String> readData(){
	   Path p1 = Paths.get("c:", "mydir","data.txt");
	   try{
	     List<String> data=   Files.readAllLines(p1); 
            return data;		 
	   }catch(IOException ex){
	       System.out.println(ex);
	   }
	  return null;
	}
	
      protected abstract void  reportStyle(List<String> dataList);
      
      public void export(){
	 List<String> dataList =  readData();
	 reportStyle(dataList);
      }
}
