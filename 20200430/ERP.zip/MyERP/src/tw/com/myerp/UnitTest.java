/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.myerp;

import java.util.List;
//extends MyERP
 class UnitTest  {
//    public void reportStyle(List<String> dataList){
//	System.out.println(dataList);
//    }
//    public static void main(String[] args) {
//	 MyERP myErp = new UnitTest();
//	 myErp.export();
//    }
    
}
