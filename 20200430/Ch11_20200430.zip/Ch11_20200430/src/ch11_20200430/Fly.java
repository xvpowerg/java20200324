/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20200430;
//介面一般方法 都是抽象
public interface Fly { 
    // 預設情況是public static final
      int MAX_SPEED=600;
    //預設情況下 讀取權限為public 類型為:抽象
    //public abstract void flying();   
     void flying(); 
     //java 8才可使用
     public default void  checkSpeed(int flySpeed){
	   if (flySpeed > MAX_SPEED || flySpeed < 0 ){
	       System.out.println("錯誤的速度");
	   }
     }
}
