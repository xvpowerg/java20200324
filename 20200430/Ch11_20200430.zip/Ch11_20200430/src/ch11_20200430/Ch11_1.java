/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20200430;

/**
 *
 * @author xvpow
 */
public class Ch11_1 {
    public static void main(String[] args) {
	Animal dog = new Dog("DoDo",5);
	dog.bark();
	System.out.println(dog);
    }
    
}
