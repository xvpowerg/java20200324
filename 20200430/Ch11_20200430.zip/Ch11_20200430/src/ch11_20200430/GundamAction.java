/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20200430;

/**
 *
 * @author xvpow
 */
//介面跟介面的關係是繼承
public interface GundamAction extends Fly,Run,Jump,Attack  {
    
}
