/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20200430;
//如果類別有抽象方法此類別一定是抽象的
//如果類別是抽象的不一定要有抽象方法
public abstract  class Animal {
    private String name;
    private int age;
    //abstract 我希望提醒開發人員 要覆寫此方法
    public abstract void bark();
    public Animal(String name, int age){
	this.name = name;
	this.age = age;
    }
    
    public String toString(){
	return name+":"+age;
    }
}
