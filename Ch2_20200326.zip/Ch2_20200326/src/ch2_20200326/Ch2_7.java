/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200326;

/**
 *
 * @author xvpow
 */
public class Ch2_7 {
    public static void main(String[] args){
	//switch 可傳的參數有
	//byte short int char String enum
	// 能放在case的變數必須是常數
	//常數不可修改之數
	 final int RUN = 1;
	 final int JUMP = 2;
	int action =6;
	switch(action){
	    case RUN:
		System.out.println("跑");
	      break;
	    case 2:
		System.out.println("跳");		
		break;
	  default:
	       System.out.println("錯誤");
	        break; 
	}
	
    }
}
