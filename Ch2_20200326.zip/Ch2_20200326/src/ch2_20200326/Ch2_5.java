/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200326;

/**
 *
 * @author xvpow
 */
public class Ch2_5 {
    public static void main(String[] args){
	int age = 31;
	//5 張口罩　>=7  <=16
	//2 張口罩 > 16
	
//	if (age >= 7 && age <= 16){
//	    System.out.println("5張口罩");
//	}else{
//	    System.out.println("2張口罩");
//	}
	//if else if else
	if (age > 16 && age <= 200){
	     System.out.println("2張口罩");
	}else if(age > 7 && age <= 16){
	    System.out.println("5張口罩");    
	}else{
	    System.out.println("無法領取!!");
	}	 
	
	
	
    }
}
