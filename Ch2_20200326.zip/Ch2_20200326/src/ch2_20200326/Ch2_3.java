/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200326;

/**
 *
 * @author xvpow
 */
public class Ch2_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	//且 或 反向 互斥
	//且 && 兩邊為真才為真  
	      //當左邊為false 會有短路現象 要把最有可能是false條件放在左邊
	// 或 || 單邊為真就是真 當左邊為true 會有短路現象 
	      //要把最有可能是true條件放在左邊
	//& | 不會有短路現象      
	//!反向 唱反調
	//互斥 ^ 一真一假才為真
	
	/*boolean b1 = true;
	boolean b2 = false;
	System.out.println( b2 && b1);//false
	System.out.println(b1 || b2);//true
	System.out.println(!b1);//false
	System.out.println(b1 ^ b2);//true*/
	/*int k = 1;
	boolean b3 = ++k <2 && k++ >1;
	System.out.println(b3);
	System.out.println(k);
	
	int y = 1;
	boolean b4 = ++y <3 && y++ >=3;
	System.out.println(b4);
	System.out.println(y);*/
	
	int x = 1;
	boolean b5 = ++x > 2 || x-- < 2;
	             //2 > 2  || 2 < 2
		     //x = 2 - 1
	System.out.println(b5);
	System.out.println(x);
	int y = 2;
	boolean b6 = y++ < 3 || y++ > 6; //短路啟動
	System.out.println(b6);
	System.out.println(y);
	
    }
    
}
