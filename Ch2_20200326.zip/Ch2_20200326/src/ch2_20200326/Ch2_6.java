/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200326;

/**
 *
 * @author xvpow
 */
public class Ch2_6 {
    public static void main(String[] args){
	//如果if沒有{}能限制的條件只有最接近if的條件
	int x = 9;
	if (x < 6)
	  System.out.println("1 x小於6");//他受到約束
	  System.out.println("2 x小於6");

	
	
    }
}
