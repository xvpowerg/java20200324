/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200326;

/**
 *
 * @author xvpow
 */
public class Ch2_4 {
      public static void main(String[] args){
	  int a1 = 1653;
	  int a2 = 792;
	  System.out.println(a1 & a2);
	  System.out.println(a1 | a2);
	  System.out.println(a1 ^ a2);
	  //11001110101 //1653
	  //01100011000‬ // 792
	  
	 //&01000010000
	//or11101111101
       //^  10101101101
      }
}
