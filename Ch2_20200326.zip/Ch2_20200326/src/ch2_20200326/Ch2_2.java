/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200326;

/**
 *
 * @author xvpow
 */
public class Ch2_2 {
    public static void main(String[] args){
	//Pool 池	
	// == 如果比較的是 參考型別 那麼比較的是記憶的位置
	String name1 = "Ken";
	String name2 = "Ken";
	String name3 = new String("Ken");
	System.out.println(name1 == name2);
	System.out.println(name1 == name3);
	//String 的 equals會拿字串中的每個字元去比較
	//如果為非基本型態 比較相等請使用equals
	System.out.println(name1.equals(name2));
	System.out.println(name1.equals(name3));
	
	// java.lang.NullPointerException
	String name4 = null; //什麼都沒有
	 System.out.println(name4.equals(name3));

    }
}
