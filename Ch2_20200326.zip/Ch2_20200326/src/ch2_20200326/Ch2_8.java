/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200326;

/**
 *
 * @author xvpow
 */
public class Ch2_8 {
    public static void main(String[] args){
	final String KEN = "Ken";
	final String VIVIN = "Vivin";
	String name = null;
//	    if (name.equals("Ken")){
//		System.out.println("資深工程師");
//	    }else if(name.equals("VIVIN")){
//		System.out.println("業務");
//	    }
	switch(name){
	    case KEN:
		System.out.println("資深工程師");
		break;
	    case VIVIN:
		System.out.println("業務");
		break;
	    case "Join":
		System.out.println("QA");
		break;
	    default:
		System.out.println("查無此人");
		break;
	}
	
    }
}
