/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200326;

/**
 *
 * @author xvpow
 */
public class Ch2_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	// TODO code application logic here
	//作業
    //請宣告一個pi 變數 與一個半徑  
    //運用這兩個變數 算圓面積!
    //公式:pi * r * r
	float pi = 3.1415f;
	int r = 10;
	float a = pi * r * r;
	System.out.println(a);
	
    }
    
}
