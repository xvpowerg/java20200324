/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch23_20200611;
import java.io.File;

import java.io.InputStream;
import java.io.FileInputStream;

import java.io.OutputStream;
import java.io.FileOutputStream;

import java.io.FileNotFoundException;
import java.io.IOException;
public class Ch23_3 {

    public static void main(String[] args) {
	File src = new File("C:\\MyDir\\test.zip");
	File target = new File("C:\\MyDir\\test_copy.zip");
	InputStream input = null;
	 OutputStream out = null;
	try{
	    input = new FileInputStream(src);
	    out = new FileOutputStream(target);
// 自定義Buffer  
	byte[] buffer = new byte[1024];
	int index = -1;
	while ( (index = input.read(buffer))!= -1   ){
	    out.write(buffer, 0, index);
	}
       }catch(FileNotFoundException ex){
	       System.out.println(ex);
        }catch(IOException ex){
	       System.out.println(ex);
	}finally{
	    try{
		 out.close();
	        input.close();
	    }catch(IOException ex){
		
	    }
	   
	}
	
    }
    
}
