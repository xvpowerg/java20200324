/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch23_20200611;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
public class Ch23_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	 // 表示myFile這個檔案
	File src = new File("C:\\MyDir\\myFile.txt");
	File target = new File("C:\\MyDir\\myFile_Copy.txt");
	try{
	    InputStream input = new FileInputStream(src);
	    OutputStream out = new FileOutputStream(target);
	    //data為-1的情況是檔案已讀完
	    int data = -1;	
	    while(  (data = input.read()) != -1 ){
		//System.out.println(data);
		out.write(data);
	    }
	}catch(FileNotFoundException ex){
	    System.out.println(ex);
	}catch(IOException ex){
	    System.out.println(ex);
	}
	
	
	
    }
    
}
