/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch23_20200611;

import java.io.File;
import java.io.FileInputStream;
import java.io.BufferedInputStream;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.BufferedOutputStream;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 *
 * @author xvpow
 */
public class Ch23_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	 // 表示myFile這個檔案
	File src = new File("C:\\MyDir\\test.zip");
	File target = new File("C:\\MyDir\\test_copy.zip");
	InputStream input = null;
	 OutputStream out = null;
	try{
	     input = new BufferedInputStream(new FileInputStream(src))  ;
	      out = new BufferedOutputStream(new FileOutputStream(target));
	    //data為-1的情況是檔案已讀完
	    int data = -1;	
	    while(  (data = input.read()) != -1 ){
		//System.out.println(data);
		out.write(data);
	    }	    
	}catch(FileNotFoundException ex){
	    System.out.println(ex);
	}catch(IOException ex){
	    System.out.println(ex);
	}finally{
	    try{
		 out.close();
	         input.close();
	    }catch(IOException ex){
		
	    }
	   
	}
	//finally 無論如何一定會執行一次
    }
    
}
