/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch23_20200611;
import java.io.File;
import java.io.Reader;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
public class Ch23_4 {
    public static void main(String[] args) {
	File src = new File("C:\\MyDir\\myFile.txt");
	//Auto close
//	try(FileReader fr = new FileReader(src);){
//	    int myData = -1;
//	    while ( (myData = fr.read()) !=-1) {
//		char myChar = (char)myData;
//	         System.out.print(myChar);
//	    }
//	}catch(FileNotFoundException ex){
//	    System.out.println(ex);
//	}catch(IOException ex){
//	     System.out.println(ex);
//	}
	
	
	
	 try(BufferedReader fr = new BufferedReader(new FileReader(src));){	     
	    String myData = null;
	    StringBuilder sb = new StringBuilder();
	    while ( (myData = fr.readLine()) !=null) {
		  sb.append(myData);
		  sb.append("\n");
	    }
	     System.out.print(sb);
	}catch(FileNotFoundException ex){
	    System.out.println(ex);
	}catch(IOException ex){
	     System.out.println(ex);
	}
	
	
	
    }
    
}
