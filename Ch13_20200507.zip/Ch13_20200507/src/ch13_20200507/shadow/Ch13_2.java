/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20200507.shadow;

/**
 *
 * @author xvpow
 */
public class Ch13_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	TestObject2 tob1 = new TestObject2();
	tob1.value1 = "TestObject2 !!!";
	
	System.out.println(tob1.getValue1());
	System.out.println(tob1.value1);
    }
    
}
