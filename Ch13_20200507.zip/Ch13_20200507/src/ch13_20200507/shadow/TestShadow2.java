/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20200507.shadow;

/**
 *
 * @author xvpow
 */
public class TestShadow2 extends TestShadow1 {
      static String staticValue1 = "TS2 staticValue1";
      String value2 = "TS2 value2";
    
     static void staticMethod(){
	 System.out.println("TestShadow2 staticMethod");
     }
     void method(){
	 System.out.println("TestShadow2 method");
     }
}
