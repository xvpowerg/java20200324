/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20200507.shadow;

/**
 *
 * @author xvpow
 */
public class Ch13_1 {

    //Shadow(遮蔽) 討論
    //父類別與子類別 靜態或非靜態變數與靜態方法 名稱一樣時的行為
    //記憶要點
    //屬性與靜態看類別
    //非靜態方法看物件
    public static void main(String[] args) {
	
	TestShadow1 ts1 = new TestShadow2();
	//1  覆寫
	ts1.method();
	//Shadow(遮蔽)
	ts1.staticMethod();
	//Shadow(遮蔽)
	System.out.println(ts1.staticValue1);
	System.out.println(ts1.value2);
	
       TestShadow2 ts2 = new TestShadow2();
       //Shadow(遮蔽)
	ts2.staticMethod();
	//Shadow(遮蔽)
	System.out.println(ts2.staticValue1);
	//等同於System.out.println(ts2.staticValue1);
	System.out.println(TestShadow2.staticValue1);
	System.out.println(ts2.value2);
    }
    
}
