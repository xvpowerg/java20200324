/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20200507.shadow;

/**
 *
 * @author xvpow
 */
public class TestObject1 {
    String value1 = "value1 TestObject1";
    public void setValue1(String value1){
	this.value1 = value1;
    }
    public String getValue1(){
	return value1;
    }
    
}
