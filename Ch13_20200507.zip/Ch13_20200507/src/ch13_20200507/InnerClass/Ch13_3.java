/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20200507.InnerClass;
import java.util.ArrayList;
public class Ch13_3 {
   
    //內部類大多數是解決實作介面
    // 內部類有分三種
    //1 靜態
    //2 非靜態
    //3 匿名
    //跟一般類一樣 但可以將其封裝在其他類別中 方便實作介面
    //1 靜態內部類
    private static class FilterByKeyword implements Filter{
	String keyword = "" ;
	FilterByKeyword(String keyword){
	    this.keyword = keyword;
	}
	public boolean filter(String value){
	    return value!=null && value.indexOf(keyword) >= 0;
	}
    }
    
    public static void main(String[] args) {
	//過濾name長度小於5的
	    MyNameFilter myFilter = new MyNameFilter();
	ArrayList<String> list =  
		Filter.doFilter(myFilter, 
	"Vivin","Ken","Lindy","Tom");
	list.forEach(System.out::println);
	System.out.println("==========================");
	FilterByKeyword filterByKey = new FilterByKeyword("n");
	ArrayList<String> list2 =  
		Filter.doFilter(filterByKey, 
	"Vivin","Ken","Lindy","Tom");
	list2.forEach(System.out::println);
	
    }
}
