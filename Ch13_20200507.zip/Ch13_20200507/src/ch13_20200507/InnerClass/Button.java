/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20200507.InnerClass;

/**
 *
 * @author xvpow
 */
public class Button {
    private OnClick onClick = null;
    public void setOnClick(OnClick onClick){
	this.onClick = onClick;
    }
    public void btnClick(){
	if (onClick != null){
	    onClick.click();
	}
    }
}
