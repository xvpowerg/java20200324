/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20200507.InnerClass;
import java.util.ArrayList;
public interface Filter {
    boolean filter(String vale);
    static ArrayList<String> doFilter(Filter nameFilter,String ... names){
	ArrayList<String> nameList = new  ArrayList<>();
	for (String n : names){
	    if (nameFilter.filter(n)){
		nameList.add(n);
	    }
	}
	return nameList;
    }
}
