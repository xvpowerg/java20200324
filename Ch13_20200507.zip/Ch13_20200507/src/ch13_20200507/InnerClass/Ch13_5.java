/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20200507.InnerClass;

/**
 *
 * @author xvpow
 */
public class Ch13_5 {

    static class MyClickLintener implements OnClick{
	   public void click(){
	       System.out.println("Btn1按下去了");
	   }
    }
    public static void main(String[] args) {
	Button btn1 = new Button();
	btn1.setOnClick(new MyClickLintener());
	btn1.btnClick();
	
	Button btn2 = new Button();
	//匿名內部類
	btn2.setOnClick(new OnClick(){
	   public void click(){
	       System.out.println("Btn2 Clcik!!");
	   }
	});
	btn2.btnClick();
	
	Button btn3 = new Button();
	//Lamdba
	btn3.setOnClick(()->{
	    System.out.println("Button 3 click");	    
	});
	btn3.btnClick();
	//匿名內類別可覆寫類別
	Dog dog = new Dog(){
	    public void bark(){
		System.out.println("喵喵!!");
	    }
	};
	dog.bark();
    }
    
}
