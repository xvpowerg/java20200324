/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20200507.InnerClass;


public class MyNameFilter implements Filter {
    public boolean filter(String value){
	return value.length() >= 5;
    }
}
