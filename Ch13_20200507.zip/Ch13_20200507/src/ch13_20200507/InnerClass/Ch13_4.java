/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20200507.InnerClass;
import java.util.ArrayList;
public class Ch13_4 {
    private class FilterEndsWith implements Filter{
	private String endKeyWord = "";
	FilterEndsWith(String endKeyWord){
	    this.endKeyWord = endKeyWord;
	}
	public boolean filter(String value){
	    return value!=null && value.endsWith(endKeyWord);
	}
    }
	
    public void testFilter(){
	FilterEndsWith few = new FilterEndsWith("e");
	ArrayList<String> list =  Filter.doFilter(few, "Banana","Charry","Apple");
	list.forEach(System.out::println);
    }
    
    public static void main(String[] args) {
	String v1 = "";
//	Ch13_4 ch134 = new Ch13_4();
//	ch134.testFilter();
	
	Ch13_4.FilterEndsWith fen = new Ch13_4().new FilterEndsWith("e");
	 System.out.println( Filter.doFilter(fen, "Apple"));
    }
}
