/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch17_20200521;
import java.util.List;
import java.util.LinkedList;
import java.util.Queue;
public class Ch17_1 {

    static void printQueue(Queue<String> q){
	System.out.println("========Queue========");
	for (String n : q){
	    System.out.print(n+" ");
	}
	System.out.println();
	System.out.println("=======Queue=========");
    }
    public static void main(String[] args) {
	List<String> list = new LinkedList<>();
	list.add("Howard");
	list.add("Iris");
	list.add("Ken");
	list.add("Join");
	list.add("Lindy");		
	for (String n : list){
	    System.out.print(n+" ");
	}
	System.out.println();
	
	Queue<String> myQueue =(Queue) list;
	printQueue(myQueue);
	myQueue.offer("Lucy");//新增
	printQueue(myQueue);
	String name = myQueue.poll();
	String name2 = myQueue.poll();
	System.out.println(name);
	System.out.println(name2);
	printQueue(myQueue);
	myQueue.offer(name);
	printQueue(myQueue);
	String name3 = myQueue.peek();
	System.out.println("name3:"+name3);
	printQueue(myQueue);
	
	
    }
    
}
