/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch17_20200521;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Queue;
public class Ch17_2 {
    public static void main(String[] args) {
	Queue<String> queue = new LinkedList<>();
	queue.offer("A");
	queue.offer("D");
	queue.offer("E");
	queue.offer("G");
	queue.offer("B");
	    

	String n =  null;
	while(  (n = queue.poll())!=null   ){
	   System.out.println(n);
	}
	//使用 poll()跑while迴圈 輪巡所有Queue的數值
	ArrayList arrayList = new ArrayList(100);
    }
    
}
