/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch17_20200521;

/**
 *
 * @author xvpow
 */
public class Product {
    private String name;
    private int price;
    public Product( String name,int price){
	this.name = name;
	this.price = price;
    }
    public String getName(){
	return name;
    }
    public int getPrice(){
	return price;
    }
    
    public String toString(){
	return name+":"+price;
    }
    
    public boolean equals(Object obj){
	System.out.println(this+":equals:"+obj);
	if (obj == null || obj instanceof Product == false){
	    return false;
	}
	Product tmp = (Product)obj;
	return this.name.equals(tmp.name) && this.price == tmp.price;
    }
    //hashCode 相等 物件不一定相等
    //hashCode 不相等 物件一定不相等
    public int hashCode(){
	return name.hashCode() + price;  
    }
}
