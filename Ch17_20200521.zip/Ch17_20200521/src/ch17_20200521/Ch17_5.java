/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch17_20200521;
import java.util.TreeSet;
public class Ch17_5 {
    public static void main(String[] args) {
	TreeSet<Integer> treeSet = new TreeSet<>();
	treeSet.add(25);
	treeSet.add(11);
	treeSet.add(30);
	treeSet.add(7);
	treeSet.add(18);
	for (int v : treeSet){
	    System.out.print(v+" ");
	}
	  System.out.println();
	  
	  int min = treeSet.first();
	  int max = treeSet.last();
	  System.out.println(min);
	   System.out.println(max);
	   //n = 21
	   int n = 25;
	  int v1 =  treeSet.ceiling(n);//treeSet 中大於等於n的
	  int v2  =treeSet.higher(n);//treeSet 中大於n的
	  System.out.println(v1);
	   System.out.println(v2);
    }
    
}
