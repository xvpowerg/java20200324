/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch17_20200521;
import java.util.Set;
import java.util.HashSet;
import java.util.List;
import java.util.LinkedList;
public class Ch17_3 {
    
    public static void main(String[] args) {
	Set<Integer> mySet = new HashSet();
	mySet.add(10);
	mySet.add(2);
	mySet.add(6);
	mySet.add(1);
	mySet.add(2);
	
	for (Integer v : mySet){
	    System.out.print(v+" ");
	}
	   System.out.println();
	//Set to List
	List<Integer> list = new LinkedList<>();
	 list.addAll(mySet);
	 System.out.println(list);
    }
}
