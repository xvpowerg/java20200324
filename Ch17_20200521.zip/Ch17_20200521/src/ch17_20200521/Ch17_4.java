/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch17_20200521;
import java.util.Set;
import java.util.HashSet;
public class Ch17_4 {

    public static void main(String[] args) {
	Product p1 = new Product("Apple",2500);
	Product p2 = new Product("Htc Vivie Pro",61200);
	Product p3 = new Product("Ps VR",7500);
	Product p4 = new Product("Htc Vivie Pro",61200);
	Set<Product> pSet = new HashSet<>();
	System.out.println(p2.equals(p4));
	pSet.add(p1);
	pSet.add(p2);
	pSet.add(p3);
	pSet.add(p4);
	for (Product p :pSet){
	    System.out.println(p);
	}
    }
    
}