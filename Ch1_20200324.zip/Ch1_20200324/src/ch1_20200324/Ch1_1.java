/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20200324;

/**
 *
 * @author xvpow
 */
public class Ch1_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	// TODO code application logic here
	//System.out.println("Test!!");
	//基本型態
	   //整數
	     //byte -128~127
	     //short -32768~32767
	     //int -2147483648 ~ 2147483647 * 預設
	     //所有非小數點的數字預設都是整數(int)
	     //long -2^63~+2^63-1
	     
	   //浮點數 
	   //float 32位元 6~7 精度(小數點位數)
	   //double 64位元 13~14精度 *
	   //所有小數點的數值預設都為double
	   float e = 2.71828f;
	   System.out.println(e);
	   //字元 0~65535
	   //小寫 > 大寫 > 數字
	    char c1 = 'A';
	    char c2 = 'a';
	    int c1Number = c1;
	    int c2Number = c2;
	    System.out.println(c1+":"+c1Number);
	    System.out.println(c2+":"+c2Number);
	    char c3 = 69;
	     System.out.println(c3);
	    char c4 = '\u0045';
	    System.out.println(c4);
	  //布林
	  boolean b1 = true;
	  boolean b2 = false;
	//參考型態
	    //常用的
	   String name = "Howard!!";
	   
	//變數名稱
	//開頭可以是英文 _ $
	//第二個開始可以是英文 _ $ 數字	
	     int value = 10;
	     int $12345 = 71;
	     int $_8_7_ = 78;
	     int A7 = 85;
    }
    
}
