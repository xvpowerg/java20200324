/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20200324;

/**
 *
 * @author xvpow
 */
public class Ch1_4 {
    public static void main(String[] args){
	/*int starCount = 0;
	starCount = starCount + 1;
	System.out.println(starCount);
	starCount = starCount + 1;
	System.out.println(starCount);
	starCount = starCount + 1;
	System.out.println(starCount);*/
	
	int starCount = 0;
	System.out.println(++starCount);
	System.out.println(++starCount);
	System.out.println(++starCount);
	
	/*int starCount = 0;
	System.out.println(starCount);
	starCount = starCount + 1;
	//檢查是否超過5顆星
	System.out.println(starCount);
	starCount = starCount + 1;
	//檢查是否超過5顆星
	System.out.println(starCount);
	starCount = starCount + 1;
	//檢查是否超過5顆星
	System.out.println("end:"+starCount);*/
	
	/*int starCount = 0;
       System.out.println(starCount++);
	//檢查是否超過5顆星
	System.out.println(starCount++);
	//檢查是否超過5顆星
	System.out.println(starCount++);
	//檢查是否超過5顆星
	System.out.println("end:"+starCount);*/
    }
}
