/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20200324;

public class Ch1_2 {
    public static void main(String[] args){
	int v1 = 10;
	int v2 = 25;
	//%d表示要印出的類型示整數
	//%n表示斷行
	System.out.printf("%d + %d = %d%n",v1,v2,v1+v2);
	System.out.printf("%d - %d = %d%n",v1,v2,v1-v2);
	System.out.printf("%d * %d = %d%n",v1,v2,v1*v2);
	//整數除整數答案還是整數
	System.out.printf("%d / %d = %d%n",v1,v2,v1/v2);
	//%f表示印出浮點數類型
	//運算當中有浮點數結果就會有浮點數
	float v3 = v2;
	System.out.printf("%d / %f = %f%n",v1,v3,v1/v3);
	
	//v4可隨意更換數字 ，餘數求得的數值範圍必定在 >=0  < v5
	int v4 = 123121231;
	int v5 = 6;
	System.out.printf("%d %% %d = %d%n",v4,v5,v4 % v5);
	
	
    }
}
