/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20200324;

/**
 *
 * @author xvpow
 */
public class Ch1_5 {
    public static void main(String[] args){
	//以下類型愛考
	/*int k = 0;
	int ans =  ++k + k++ - k++ + ++k;
		//  1  + 1  -  2 +   4
	System.out.println(ans);
	System.out.println(k);*/
	
	int v = 4;
	v += 6;//v = 6 +4
	v -= 2;//v = 10 - 2
	System.out.println(v);
	//特別的小心的特性
	int v2 = 25;
	v2 += 6.3;
	System.out.println(v2);
	
	
	
    }
}
