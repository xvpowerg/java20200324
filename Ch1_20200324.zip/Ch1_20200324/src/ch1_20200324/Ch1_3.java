/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20200324;

/**
 *
 * @author xvpow
 */
public class Ch1_3 {

    public static void main(String[] args) {
	//能加上_的位置  
	//口訣:底線前後必須是底線或數字
	int value1 = 100_000_000;
	//16進位
	int hex = 0xF01_FBA;
	//8進位
	int oct = 0_571; 
	//二進位
	int binary = 0b01_101; 
	System.out.println(hex);
    }
    
}
