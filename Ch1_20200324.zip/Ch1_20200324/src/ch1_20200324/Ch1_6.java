/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20200324;

/**
 *
 * @author xvpow
 */
public class Ch1_6 {
     public static void main(String[] args){
	 //基本型態比較 回傳都是boolean
	 int v1 = 20;
	 int v2 = 10;
	 System.out.println(v1 > v2);//true
	 System.out.println(v1 < v2);//false
	  System.out.println(v1 <= v2);//false
	  System.out.println(v1 >= v2);//true
	  System.out.println(v1 == v2);//fasle
	  //在程式語言內 !有一種 否定的意味
	  System.out.println(v1 != v2);//true
	    System.out.println(v1 = v2);//10
//作業
//請宣告一個pi 變數 與一個半徑  
//運用這兩個變數 算圓面積!
//pi * r * r
     }
}
