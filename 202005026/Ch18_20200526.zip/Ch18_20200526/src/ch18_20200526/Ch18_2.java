/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch18_20200526;
import java.util.TreeSet;
/**
 *
 * @author xvpow
 */
public class Ch18_2 {
    public static void main(String[] args) {
	TreeSet<Employee> treeSet = new TreeSet<>();
	Employee e1 = new Employee("Ken",25,25000);
	Employee e2 = new Employee("Lindy",31,32000);
	Employee e3 = new Employee("Iris",28,28000);
	Employee e4 = new Employee("Vivin",32,32000);
	
        Employee e5 = new Employee("Tom",28,65000);
	Employee e6 = new Employee("Join",32,32000);
	
	treeSet.add(e1);
	treeSet.add(e2);
	treeSet.add(e3);
	treeSet.add(e4);
	treeSet.add(e5);
	treeSet.add(e6);
	treeSet.forEach(System.out::println);
    }
    
}
