/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch18_20200526;

/**
 *
 * @author xvpow
 */
public class Employee implements Comparable<Employee> {
    private String name;
    private int age;
    private int salary;
        //如果目前的Employee 大於 inEmp 回傳正數
    //如果目前的Employee 小於 inEmp 回傳負數
    //如果目前的Employee 等於 inEmp 回傳0
    public int compareTo(Employee inEmp){
	if (this.getSalary() > inEmp.getSalary()){
	    return 1;
	}else if(this.getSalary() <  inEmp.getSalary()){
	    return -1;
	}else if(this.getAge() > inEmp.getAge()){
	    return 1;
	}else if(this.getAge() < inEmp.getAge()){
	    return -1;
	}
	return this.getName().
		compareTo(inEmp.getName());
    }
    
    
    Employee(String name,int age,int salary){
	this.name = name;
	this.age = age;
	this.salary = salary;
    }
    public String getName(){
	return name;
    }
    public int getAge(){
	return age;
    }
    public int getSalary(){
	return salary;
    }
    public String toString(){
	return this.getName()+":"+this.getAge()+":"+this.getSalary();
    }

}
