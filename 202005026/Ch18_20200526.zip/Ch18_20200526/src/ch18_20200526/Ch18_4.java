/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch18_20200526;

import java.util.TreeSet;
import tw.com.bean.Product;
import java.util.Comparator;

public class Ch18_4 {

    public static void main(String[] args) {
	Product p1 = new Product("Apple",10,5);
	Product p2 = new Product("Kiwi",20,6);
	Product p3 = new Product("Banana",15,2);
	Product p4 = new Product("Apple",20,5);
	Product p5 = new Product("Book",20,10);
	
//	TreeSet<Product> pTreeSet = new TreeSet<>(( pr1, pr2)->{
//		if (pr1.getCount() > pr2.getCount()){
//		    return 1;
//		}else if(pr1.getCount() < pr2.getCount()){
//		    return -1;
//		}
//	    return 0;});
     // 回傳要排什麼東西
     //comparing 回傳的東西 必須要實作過Comparable
    Comparator<Product> myCmp = Comparator.
	    <Product,Integer>comparing((p)->p.getCount()).
	    thenComparing(p->p.getPrice()).
	    thenComparing(p->p.getName());
	myCmp = myCmp.reversed();//遞減排序
	TreeSet<Product> pTreeSet = new TreeSet<>(myCmp);
	pTreeSet.add(p1);
	pTreeSet.add(p2);
	pTreeSet.add(p3);
	pTreeSet.add(p4);
	pTreeSet.add(p5);
	
	pTreeSet.forEach(System.out::println);
	
    }
    
}
