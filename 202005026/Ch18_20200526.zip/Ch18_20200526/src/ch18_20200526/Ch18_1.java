/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch18_20200526;
import java.util.TreeSet;
public class Ch18_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	//Linked 與 List 系列都是依照新增時的順序,決定取出的順序
	//TreeXXX 都是可排序的
	//Hash 都是無順序的
       //效能	
       //Hash >　Linked　>　Tree
       TreeSet <Integer> treeSet = new TreeSet();
       treeSet.add(25);
       treeSet.add(6);
       treeSet.add(12);
       treeSet.add(21);
       treeSet.add(2);
       treeSet.forEach(System.out::println);
       System.out.println("================");
       int n =  21;
      System.out.println(treeSet.ceiling(n));//treeSet內大於等於n的
      System.out.println(treeSet.higher(n));//treeSet內大於n的

      int y = 6;
      System.out.println(treeSet.floor(y));//treeSet內小於等於y
      System.out.println(treeSet.lower(y));//treeSet內小於y
      
      TreeSet<String> nameSet = new TreeSet();
     nameSet.add("C");
     nameSet.add("B");
     nameSet.add("A");
     
    }
    
}
