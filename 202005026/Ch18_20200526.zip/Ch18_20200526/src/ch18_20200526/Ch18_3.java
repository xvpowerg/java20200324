/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch18_20200526;
import tw.com.bean.Product;
import java.util.TreeSet;
import java.util.Comparator;
public class Ch18_3 {
    enum SortType{
	ASC,//遞增排序
	DESC//遞減排序
    }
    private static class MyComparator implements Comparator<Product> {
	private SortType sortType;
	MyComparator(SortType type){
	    sortType = type;
	}
	MyComparator(){
	    this(SortType.ASC);
	}
	private int result = 0;
	//p1 大於　p2 回傳正數
	//p1 小於　p2 回傳負數
	//p1 等於　p2 回傳0
	public int compare(Product p1,Product p2){
	  if (p1.getCount() > p2.getCount()){
	      result= 1;
	  }else if (p1.getCount() < p2.getCount()){
	      result = -1;	      
	  }else if(p1.getPrice() > p2.getPrice()){
	      result = 1;
	  }else if(p1.getPrice() < p2.getPrice()){
	      result = -1;
	  }else{
	      result = p1.getName().compareTo(p2.getName());
	  }
	  
	  return sortType==SortType.ASC? result:result*-1;
	}
    }
    public static void main(String[] args) {
	Product p1 = new Product("Apple",10,5);
	Product p2 = new Product("Kiwi",20,6);
	Product p3 = new Product("Banana",15,2);
	Product p4 = new Product("Apple",20,5);
	Product p5 = new Product("Book",20,10);
	
	MyComparator cmp = new MyComparator(SortType.DESC);
	TreeSet<Product> pTreeSet = new TreeSet(cmp);
	pTreeSet.add(p1);
	pTreeSet.add(p2);
	pTreeSet.add(p3);
	pTreeSet.add(p4);
	pTreeSet.add(p5);
	
	pTreeSet.forEach(System.out::println);
    }
    
}
