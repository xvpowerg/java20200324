/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch22_20200609;
import java.util.Optional;
import java.util.stream.Stream;
/**
 *
 * @author xvpow
 */
public class Ch22_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	Stream<Integer> st1 = Stream.of(20,10,30,40,50);
	//reduce 合併
	Optional<Integer> op1 = st1.reduce((v1,v2)->{
	    System.out.println(v1+":"+v2); 
	    return v1+v2;});
	System.out.println(op1.get());
	
	Stream<Integer> st2 = Stream.of(20,10,30,40,50);
	int ans = st2.reduce(5, (v1,v2)->{
	    System.out.println(v1+":"+v2);
	    return v1+v2;
	});
	System.out.println("Ans:"+ans);
	
	Stream<Integer> st3 = Stream.of(1,2,3,4,5);
	//combiner 只有在parallel 才會呼叫
	//parallel時會先將數值與n在accumulator合併計算
	//最後結果是在combiner時產出
	int n = 0;
	int ans2= 
	st3.parallel().reduce( n, 
			(v1,v2)->{System.out.println("A: "+v1+":"+v2); 
			return v1 + v2;},
		      (v1,v2)->{System.out.println("C: "+v1+":"+v2); 
		      return v1+v2;});
	System.out.println(ans2);
	
	
	
    }
    
}
