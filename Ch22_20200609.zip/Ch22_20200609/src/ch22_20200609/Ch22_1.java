/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch22_20200609;

import java.util.Optional;

/**
 *
 * @author xvpow
 */
public class Ch22_1 {


    public static void main(String[] args) {
	String value = "Vivin";
	Optional<String>op =  Optional.ofNullable(value);
	if (op.isPresent()){
	  System.out.println("get:"+op.get());  //java.util.NoSuchElementException
	}
	op.ifPresent(v->System.out.println(v));
	//如果Optional存放的內容為null 就回傳empty
	String msg1 = op.orElse("empty");
	System.out.println(msg1);
	String msg2 =  op.orElseGet(()->"ElseGet");
	System.out.println(msg2);
	op.orElseThrow(IllegalArgumentException::new);
	
    }
    
}
