/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch22_20200609;
import java.util.List;
import java.util.ArrayList;
import java.util.stream.Stream;
/**
 *
 * @author xvpow
 */
public class Student {
    private String name;
    private int age;
    private List<Book> books = new ArrayList();
    public Student(String name, int age) {
	this.name = name;
	this.age = age;
    }

    public String getName() {
	return name;
    }

    public int getAge() {
	return age;
    }

    public void appendBook(Book book){
	this.books.add(book);
    }
    public Stream<Book> getBooks() {
	return books.stream();
    }
    @Override
    public String toString() {
	return "Student{" + "name=" + name + ", age=" + age + '}';
    }
    
    
    
}
