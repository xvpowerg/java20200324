/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch22_20200609;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 *
 * @author xvpow
 */
public class Ch22_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
		ArrayList<Student> stList = new ArrayList<>();
	Student st1 = new Student("Ken",25);
	Student st2 = new Student("Lucy",31);
	Student st3 = new Student("Gigi",13);
	Student st4 = new Student("Iris",15);
	Student st5 = new Student("Tom",27);
	Student st6 = new Student("Lindy",35);
	Student st7 = new Student("Ivy",45);
	stList.add(st1);
	stList.add(st2);
	stList.add(st3);
	stList.add(st4);
	stList.add(st5);
	stList.add(st6);
	stList.add(st7);
	Map<Integer,List<Student>> group =  
		stList.stream().collect(Collectors.groupingBy(st->st.getAge()/10));
	System.out.println(group);
	 
	Map<Boolean,List<Student>> pGroup = 
		stList.stream().collect(Collectors.partitioningBy(st->st.getAge() >=18 ));
	System.out.println(pGroup);
	
	String msg = stList.stream().map(st->st.getName()).
		collect(Collectors.joining(",", "names:", "."));
	System.out.println(msg);
	
	
    }
    
}
