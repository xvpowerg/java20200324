/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch22_20200609;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 *
 * @author xvpow
 */
public class Ch22_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	ArrayList<Student> stList = new ArrayList<>();
	Student st1 = new Student("Ken",25);
	st1.appendBook(new Book("BookA","00001"));
	st1.appendBook(new Book("BookB","00002"));
	Student st2 = new Student("Lucy",71);
	st2.appendBook(new Book("BookC","00003"));
	st2.appendBook(new Book("BookD","00004"));
	Student st3 = new Student("Gigi",13);
	st3.appendBook(new Book("BookE","00005"));
	st3.appendBook(new Book("BookF","00006"));
	st3.appendBook(new Book("BookF","00007"));
	st3.appendBook(new Book("BookD","00008"));
	stList.add(st1);
	stList.add(st2);
	stList.add(st3);
	List<Book> bookList = 
		stList.stream().flatMap(st->st.getBooks()).
			collect(Collectors.toList());
	System.out.println(bookList);
//	LinkedList<Book> bookList2 = stList.stream().flatMap(st->st.getBooks()).
//			collect(Collectors.toCollection(LinkedList::new));
  Map<String,Book> bookMap = stList.stream().flatMap(st->st.getBooks()).collect(
	   Collectors.toMap(b->b.getIsbn(), b->b));
  System.out.println(bookMap);
  
   Map<String,List<Book>> bookMap2 = stList.stream().flatMap(st->st.getBooks()).collect(
	   Collectors.toMap(b->b.getName(), b->{
	   List<Book> booklist = new ArrayList<>();
	   booklist.add(b);
	   return booklist;
	   },(v1,v2)->{
	     v1.addAll(v2);
	       return v1;
	   }));
    System.out.println(bookMap2);
    
    
    }
    
}
