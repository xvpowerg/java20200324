/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch22_20200609;
import java.util.ArrayList;
import java.util.List;
public class Ch22_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	ArrayList<Student> stList = new ArrayList<>();
	Student st1 = new Student("Ken",25);
	st1.appendBook(new Book("BookA","00001"));
	st1.appendBook(new Book("BookB","00002"));
	Student st2 = new Student("Lucy",71);
	st2.appendBook(new Book("BookC","00003"));
	st2.appendBook(new Book("BookD","00004"));
	Student st3 = new Student("Gigi",13);
	st3.appendBook(new Book("BookE","00005"));
	st3.appendBook(new Book("BookF","00006"));
	stList.add(st1);
	stList.add(st2);
	stList.add(st3);
	//flatMap 可以把 getBooks() 回傳的Stream 展開來集合成一個新的Stream
	stList.stream().flatMap(st->st.getBooks()).forEach(System.out::println);
	//stList.stream().map(st->st.getBooks()).forEach(s->s.forEach(System.out::println));	
//	List<Book> bookList = st1.getBooks();
//	bookList.clear();
//	for (Book b1 :bookList){
//	    System.out.println(b1);
//	}
	
    }
    
}
