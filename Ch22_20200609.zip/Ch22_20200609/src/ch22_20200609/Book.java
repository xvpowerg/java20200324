/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch22_20200609;

/**
 *
 * @author xvpow
 */
public class Book {
    private String name;
    private String isbn;

    public Book(String name, String isbn) {
	this.name = name;
	this.isbn = isbn;
    }

    public String getName() {
	return name;
    }

    public String getIsbn() {
	return isbn;
    }

    @Override
    public String toString() {
	return "Book{" + "name=" + name + ", isbn=" + isbn + '}';
    }
    
}
