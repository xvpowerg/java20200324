/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch22_20200609;
import java.util.ArrayList;
/**
 *
 * @author xvpow
 */
public class Ch22_2 {

    public static void main(String[] args) {
	
	ArrayList<String> list = new ArrayList<>();
	list.add("Ken");
	list.add("Vivin");
	list.add("Lucy");
	list.add("Tom");
	list.add("Join");
	list.add("Vivin");
	//distinct 過濾重複的
	list.stream().distinct().forEach(System.out::println);
	//map 一種轉換
	list.stream().map(n->new Student(n,0)).forEach(System.out::println);
	
	
	
    }
    
}
