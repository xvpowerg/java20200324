/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch21_20200604;
import java.util.ArrayList;
import java.util.stream.Stream;
public class Ch21_2 {

    public static void main(String[] args) {
	ArrayList<Fruit> fruitList = new ArrayList<>();
	Fruit f1 = new Fruit("Apple",50);
	Fruit f2 = new Fruit("Cherry",70);
	Fruit f3 = new Fruit("Banana",20);
	Fruit f4 = new Fruit("Kiwi",10);
	Fruit f5 = new Fruit("Shangji",82);
	fruitList.add(f1);
	fruitList.add(f2);
	fruitList.add(f3);
	fruitList.add(f4);
	fruitList.add(f5);
	//只要Stream內有一個符合條件 回傳true
	boolean b1 = fruitList.stream().anyMatch((f)->f.getPrice() < 15);
	System.out.println(b1);
	//anyMatch 只要回傳true就短路
	 b1 = fruitList.stream().peek(f->System.out.println("peek1:"+f)).
			   anyMatch((f)->f.getPrice() < 15);
	 System.out.println(b1);
	//要Stream所有符合條件 回傳true
	boolean b2 =  fruitList.stream().allMatch(f->f.getPrice() > 5);
	System.out.println(b2);	
	//allMatch Stream條件回傳false的 就短路
	b2 =  fruitList.stream().peek(f->System.out.println("peek2:"+f)).
				allMatch(f->f.getPrice() < 70);
	System.out.println(b2);
	//要Stream內所有條件都不符合 回傳true
	boolean b3 =  fruitList.stream().noneMatch(f->f.getPrice() <2);
	System.out.println(b3);
	//noneMatch 回傳false的 就短路
	b3 =  fruitList.stream().peek(v->System.out.println("peek3:"+v)).noneMatch(f->f.getPrice() >= 70);
	System.out.println(b3);
	
    }
    
}
