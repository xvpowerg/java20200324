/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch21_20200604;
import java.util.Optional;
public class Ch21_4 {

    public static void main(String[] args) {
	
	Fruit f1 = new Fruit(null,560);
	Optional<String> nameOp =  f1.getName();
	nameOp.ifPresent(n->{
	    if ( n.indexOf("A") >= 0 ){
		System.out.println("A貨!");	    	    
	    }
	});
	
	Optional<String> testNull = Optional.empty();
	//Optional.of 不予許null
	//Optional.of(null);//java.lang.NullPointerException
	//Optional.ofNullable 予許null
        Optional.ofNullable(null);

	
	Optional<String> opStr =  Optional.ofNullable(null);
	opStr.ifPresent(c->System.out.println(c));
	if (opStr.isPresent()){
	    System.out.println(opStr.get());
	}
	//如果 ofNullable 參數是null 則以下程式會拋出
	//java.util.NoSuchElementException
	 System.out.println(opStr.get());
    }
    
}
