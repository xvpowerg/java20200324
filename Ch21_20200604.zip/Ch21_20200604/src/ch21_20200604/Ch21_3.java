/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch21_20200604;

import java.util.ArrayList;
import java.util.Optional;
/**
 *
 * @author xvpow
 */
public class Ch21_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	ArrayList<Fruit> fruitList = new ArrayList<>();
	Fruit f1 = new Fruit("Apple",50);
	Fruit f2 = new Fruit("Cherry",70);
	Fruit f3 = new Fruit("Banana",20);
	Fruit f4 = new Fruit("Kiwi",10);
	Fruit f5 = new Fruit("Shangji",82);
	fruitList.add(f1);
	fruitList.add(f2);
	fruitList.add(f3);
	fruitList.add(f4);
	fruitList.add(f5);
	
	Optional<Fruit>  opf = fruitList.stream().
		filter(f->f.getPrice() > 20).findFirst();
	System.out.println(opf.get());
	//findAny 在parallel狀況下才會隨機找數值 否則會回傳第一個
	Optional<Fruit>  opf2 = fruitList.parallelStream().
		filter(f->f.getPrice() > 20).findAny();
	System.out.println(opf2.get());
	
	Optional<Fruit>  opf3 = fruitList.stream().parallel().
		filter(f->f.getPrice() > 20).findFirst();
	System.out.println(opf3.get());
	//Stream 可呼叫parallel() 將Stream轉為parallel 
	//也可將 parallel Stream呼叫sequential() 轉為一般Stream
    }
    
}
