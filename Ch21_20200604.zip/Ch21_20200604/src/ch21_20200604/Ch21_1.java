/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch21_20200604;
import java.util.ArrayList;
import java.util.stream.Stream;
public class Ch21_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	ArrayList<String> list = new ArrayList<>();
	list.add("Iris");
	list.add("Tom");
	list.add("Ken");
	list.add("Join");
	Stream<String> str = list.stream();
	//count類型為long
	long count =  str.filter(n->n.length() > 3).count();
	System.out.println(count);
	//count =  str.filter(n->n.length() < 3).count();
	//System.out.println(count);
	//終端類型(terminal) count 是終端的方法
	count = list.stream().peek(v->System.out.println("Peek:"+v)).count();   
	System.out.println(count);
	//peek是惰性(lazy)的方法
	Stream<String> st = list.stream().peek(v->System.out.println("Peek2:"+v));
	st.filter(v->v.length() >3);
	
	
    }
    
}
