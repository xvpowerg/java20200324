/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200407;
import java.util.Arrays;
public class Ch4_6 {
    public static void main(String[] args) {
	// java 8
	int[] array = {8,1,3,2,5};
	//內迴圈
//	Arrays.stream(array).
//		forEach(System.out::println);//lambda
	int[] array2 = new int[900];
	Arrays.fill(array2, -1);//填充數值
	System.out.println(array2[0]);
	int[] array3 = {5,6,7,8,9};
	//Copy Array
	int[] array4 = Arrays.copyOf(array3, array3.length);
	System.out.println(array3[1]);
	System.out.println(array4[1]);
	array4[1] = 100;
	System.out.println(array3[1]);
	
    }
    
}
