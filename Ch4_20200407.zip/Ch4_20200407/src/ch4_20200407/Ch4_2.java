/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200407;
import java.util.Arrays;
/**
 *
 * @author xvpow
 */
public class Ch4_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	int[] array={8,3,10,21,5};

	Arrays.sort(array);
	//3 5 8 10 21
	int index = Arrays.binarySearch(array, 10);
	//找到回傳相對應的Index
	System.out.println(index);
	//找不到一定是負數
	//找不到有以下幾種情況
	//假設x為被找的數值 a為資料來源陣列
	//x 小於所有的 a 元素 一律回-1
	  int x1 = 2;
	 index = Arrays.binarySearch(array, x1);
	 System.out.println(index);
	//x 大於所有的 a 元素 (a的length + 1)*-1 
	 int x2 = 35;
	index =  Arrays.binarySearch(array, x2);
	System.out.println(index);
	//x 在 a 元素之間 x數值的下一個元素的長度 *-1
	 int x3 = 11;
	index =  Arrays.binarySearch(array, x3);
	System.out.println(index);
    }
    
}
