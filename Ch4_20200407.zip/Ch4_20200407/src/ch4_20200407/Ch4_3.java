/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200407;

/**
 *
 * @author xvpow
 */
public class Ch4_3 {

    public static void main(String[] args) {
	//左邊的[]數量一定要等於右邊的
	//3 row
	//2 col
	int[][] array3x2 = new int[3][2];
	array3x2[0][0] = 51;
	array3x2[1][1] = 32;
	array3x2[2][0] = 68;
	
	for (int[] colArray : array3x2){
	    for (int colV : colArray){
		System.out.print(colV+" ");
	    }
	    System.out.println();
	}

	/*for (int rowi =0;rowi < array3x2.length;rowi++){
	     for (int colk = 0;colk < array3x2[rowi].length;colk++){
		 System.out.print(array3x2[rowi][colk]+" ");
	     }
	     System.out.println();
	}*/
	
	
    }
    
}
