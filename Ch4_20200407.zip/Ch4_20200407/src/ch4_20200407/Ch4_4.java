/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200407;

/**
 *
 * @author xvpow
 */
public class Ch4_4 {
    public static void main(String[] args) {
	//多維陣列宣告方式
	int[][][] array3x = new int[3][2][3];
	int[][] array3a[] = new int[3][2][3];
	int[] array3b[][] = new int[3][2][3];
	int array3c[][][] = new int[3][2][3];
	
	int[][][] array3d = new int[3][][];
	int[][][] array3e = {{
				{1,5},
				{3,8}
	                      },
			      {
				{6,7},
				{9,6}   
			      }   
	                    };
	
	System.out.println(array3e[1][0][0]);

	//不規則形陣列
	int[][] array2xN = new int[2][];
	array2xN[0] = new int[2];
	array2xN[1] = new int[4];
	array2xN[0][1] = 75;
	array2xN[1][2] = 93;
	array2xN[1][0] = 68;
//	0 75
//	68 0 93 0
	for (int[] a :array2xN ){
	   for (int v : a){
	       System.out.print(v+" ");
	   }
	    System.out.println();
	}
    }
    
}
