/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200407;

/**
 *
 * @author xvpow
 */
public class Ch4_1 {

    public static void main(String[] args) {
//	int[] array = {5,6,8,1,2};
//	int sum = 0;
//	for (int i : array){
//	    sum += i;
//	}
//	System.out.println(sum);
	
	int[] array2 = {7,9,100,5,3,11};
	int max = array2[0], min = array2[0];
	for (int v : array2){
	    if ( v  > max) max = v;
	    if (v < min) min = v;
	}
	System.out.println(max);
	System.out.println(min);
	
    }
    
}
