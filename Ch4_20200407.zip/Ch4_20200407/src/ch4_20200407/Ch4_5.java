/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200407;

/**
 *
 * @author xvpow
 */
public class Ch4_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	int[][] array2 = new int[3][];
	array2[0] = new int[2];
	array2[2] = new int[5];
	array2[0][1] = 30;
	//array2[2][5] = 63;//java.lang.ArrayIndexOutOfBoundsException 因為超過索引最大長度
	array2[1][0] = 76;//java.lang.NullPointerException
//	System.out.println(array2[2][5]);
	System.out.println(array2[1][0]);
    }
    
}
