/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20200428;
import java.io.IOException;
import java.io.FileNotFoundException;
public class TestOverrideSub extends TestOverride {
    
      //  public void testCatchException()throws Exception
       // public void testCatchException()
      public void testCatchException()throws PageNotFoundException{
	
      }
      
      //以下錯誤 因為PageNotFoundException 沒有繼承IOException
     public void testCatchException2()throws IOException{
	
    }
     
    public void testUnCatchException()throws AccountAuthException{
	
    }
}
