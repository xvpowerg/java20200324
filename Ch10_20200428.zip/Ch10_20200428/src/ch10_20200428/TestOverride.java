/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20200428;
import java.io.IOException;
/**
 *
 * @author xvpow
 */
public class TestOverride {
    //覆寫例外時 可選擇拋出一樣的 或子類 或不拋出
    //以上規則若子類拋出的為非必要例外檢測時無效
    public void testCatchException()throws Exception{
	
    }
    public void testCatchException2()throws IOException{
	
    }
    
    public void testUnCatchException()throws AccountAuthException{
	
    }
    
}
