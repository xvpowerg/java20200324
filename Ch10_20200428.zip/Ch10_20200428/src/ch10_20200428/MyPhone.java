/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20200428;

/**
 *
 * @author xvpow
 */
public class MyPhone extends CellPhone {
    MyPhone(int height,String type){
	super(height,type);
    }
    public void callOut(){
	System.out.println("MyPhone Call Out!");
    }
}
