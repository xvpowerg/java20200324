/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20200428;

/**
 *
 * @author xvpow
 */
public class Student {
    private String name;
    private int age;
    Student(String name,int age){
	this.name = name;
	this.age = age;
    }
    public void setName(String name){
	this.name = name;
    }
    public String getName(){
	return this.name;
    }
    public int getAge(){
	return this.age;
    }
    
    public Student clone(){
	return new Student(this.name,this.age);
    }
    
    public String toString(){
	return this.getName()+":"+this.getAge();
    }

    public boolean equals(Object obj){
	 if (obj == null ||  obj instanceof Student == false){
	     return false;
	 }
	
	//把obj強制轉型成Student
	Student st = (Student)obj;
	return this.name.equals(st.name) &&
		this.age == st.age;
    }
}
