/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20200428;

/**
 *
 * @author xvpow
 */
public class TestException {
    public void uncatchException(int number){
	if (number < 0 ){
	    //IllegalArgumentException  用途 當傳述參數不正確時可拋出此例外
	    throw new IllegalArgumentException();
	}
	System.out.println("number:"+number);
    }
    
    public void toPage(String page)throws PageNotFoundException{
	    if (page == null){
		 throw new PageNotFoundException("page不可是null");   
	    }
    }
    
}
