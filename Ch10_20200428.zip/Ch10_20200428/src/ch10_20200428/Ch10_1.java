/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20200428;
public class Ch10_1 {
    public static void main(String[] args) {

	TestException tex = new TestException();
	tex.uncatchException(10);
	try{
	    tex.uncatchException(-5);
	}catch(IllegalArgumentException ag){
	    System.out.print(ag);
	}
	
	
    }
}
