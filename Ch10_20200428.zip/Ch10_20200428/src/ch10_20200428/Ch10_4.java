/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20200428;

/**
 *
 * @author xvpow
 */
public class Ch10_4 {
    public static void main(String[] args) {
	
	Student st1 = new Student("Ken",20);
	//任何一種將物件轉換成字串的方式 都會呼叫物件的toString()
	//會呼叫st1的toString()
	String objValue = "objValue:"+st1.toString();
	//會呼叫st1的toString()
      System.out.println(objValue);
	System.out.println(st1);
	System.out.println(st1.getClass().getName()+"@"+
		Integer.toHexString(st1.hashCode()));
	
	
    }
    
}
