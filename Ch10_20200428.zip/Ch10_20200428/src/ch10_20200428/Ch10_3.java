/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20200428;

/**
 *
 * @author xvpow
 */
public class Ch10_3 {

    public static void main(String[] args) {
	Student st1 = new Student("Ken",25);
	Student st2 = new Student("Vivin",18);
	Student st3 = new Student("Ken",25);
	//淺度Copy
	Student st4 = st3;
	System.out.println(st4.getName()+":"+st4.getAge());
	System.out.println(st3.getName()+":"+st3.getAge());
	st4.setName("Joy");
	System.out.println(st4.getName()+":"+st4.getAge());
	System.out.println(st3.getName()+":"+st3.getAge());
	//深度Copy 修改st5不會修改到st2 因為clone 內有new Student
	Student st5 = st2.clone();
	System.out.println(st2.getName()+":"+st2.getAge());
	System.out.println(st5.getName()+":"+st5.getAge());
	st5.setName("Lindy");
	System.out.println(st2.getName()+":"+st2.getAge());
	System.out.println(st5.getName()+":"+st5.getAge());
    }
    
}
