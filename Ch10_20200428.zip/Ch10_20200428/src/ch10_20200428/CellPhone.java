/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20200428;
//abstract 
//1 因為 是一種同稱 不可被new 所以我要abstract
public abstract class CellPhone {
    private int height;
    private String type="";
    
    CellPhone(int height,String type ){
	this.height = height;
	this.type = type;
    }
    public void callOut(){
	
    }
    
    public String toString(){
	return height+":"+type;
    }
}
