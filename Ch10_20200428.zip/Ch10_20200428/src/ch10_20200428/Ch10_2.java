/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20200428;

/**
 *
 * @author xvpow
 */
public class Ch10_2 {
    public static void main(String[] args) {
	TestException tex = new TestException();
	try{
	    tex.toPage(null);    
	}catch(PageNotFoundException ex){
	    System.out.println(ex);
	}
    }
}
