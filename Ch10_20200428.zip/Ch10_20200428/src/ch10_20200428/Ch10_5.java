/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20200428;

class Dog{

}
public class Ch10_5 {
    public static void main(String[] args) {
	Student st1 = new Student("Ken",12);
	Student st2 = new Student("Ken",12);
	System.out.println(st1 == st2);
	System.out.println(st1.equals(st2));
	//java.lang.ClassCastException 轉型錯誤
	//System.out.println(st1.equals(new Dog()));
	System.out.println(st1.equals(null));
	
    }
}
