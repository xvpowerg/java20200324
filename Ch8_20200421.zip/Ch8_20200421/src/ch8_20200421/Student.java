/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20200421;

public class Student extends Person {
    //所有類別都有建構子 
    //在類別內無自行添加任何建構子時 會自動產生預設建構子
    //預設建構子的樣子
    //所有建構子都會預設呼叫super()除非有添加this(可帶參數或不帶)
    // 或是其他非預設的super(可帶參數或不帶)
    public Student(){
	//super();//呼叫父類預設建構子
    }
    
    Student(String name,int age,float weight){
	super(name,age,weight);
    }
    // @Override 
    //提醒開發人員 此方法是一個Override
    //可檢查Override是否正確
    @Override
    public String getName(){
	//super. 呼叫父類別的
	return "Student:"+super.getName();
    }
}
