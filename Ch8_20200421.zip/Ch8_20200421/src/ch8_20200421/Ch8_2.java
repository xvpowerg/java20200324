/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20200421;

/**
 *
 * @author xvpow
 */
public class Ch8_2 {

    
    public static void main(String[] args) {
	//多型(polymorphism)
	//低耦合
         //耦合 目前類別跟另一類別的緊密度
	//高聚合
	 //聚合 方法的功能要緊密
	Person p1 = new Student("Ken",10,45);
	Person p2 = new Employee("Join",25,55);
	//如何由程式碼判斷 p1 是 Student p2 是  Employee
	if (p1 instanceof Student){
	    System.out.println("我是Student");
	}
	if (p2 instanceof Employee){
	    System.out.println("我是Employee");
	}
	
	
    }
    
}
