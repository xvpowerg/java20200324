/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20200421;

/**
 *
 * @author xvpow
 */
public class Ch8_3 {
    public static void main(String[] args) {
	Person p1 = new Student("Ken",10,45);
	Person p2 = new Employee("Join",25,55);  
	System.out.println(p1.getName());
	System.out.println(p2.getName());
    }
    
}
