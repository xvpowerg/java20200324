/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20200421;

/**
 *
 * @author xvpow
 */
public class Ch8_1 {
   
    static void printPersons(Person ... ps){
	for (Person p : ps){
	    System.out.println(p.getName()+":"+p.getAge()+":"+p.getWeight());
	}
    }
    
    public static void main(String[] args) {
	Person p1 = new Person("Ken",12,52);
    //	System.out.println(p1.getName()+":"+
    //		p1.getAge()+":"+p1.getWeight());
    //Ctrl + / 可快速註解多行
	Student s1 = new Student("Vivin",18,71);    
	printPersons(p1,s1);	
    }
    
}
