/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20200421.exp1;

/**
 *
 * @author xvpow
 */
public class Sub1  extends MainClass{
    Sub1(){
	System.out.println("Sub1()");
    }
    Sub1(String value){
	System.out.println("Sub1 : value "+value);
    }
}
