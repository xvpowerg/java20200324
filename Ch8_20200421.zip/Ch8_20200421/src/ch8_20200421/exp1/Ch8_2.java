/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20200421.exp1;

/**
 *
 * @author xvpow
 */
public class Ch8_2 {

    public static void main(String[] args) {
	//這類題型
	//1 先看是否會產生編譯錯誤
	 // 編譯錯誤最可能的情況是 父類無預設建構子 
	 //  子類沒有使用super呼叫適當的父類建構子
	//2 畫圖解決
	Sub2 su2 = new Sub2(20);
    }
    
}
