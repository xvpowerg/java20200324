/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20200421.exp1;

/**
 *
 * @author xvpow
 */
//Java 每個類別都extends Object
public class MainClass {
    MainClass(){
	this("Ken",2);
	System.out.println("MainClass()");
    }
     MainClass(String n1,int n2){
	System.out.println("MainClass"+n1+":" +n2);
    } 
}
