/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20200421.exp1;

/**
 *
 * @author xvpow
 */
public class Sub2 extends Sub1{
     Sub2(){
	 
	System.out.println("Sub2()");
    }
     Sub2(int n){
	 this();
	System.out.println("Sub2(int):"+n);
    }
}
