/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200414;

/**
 *
 * @author xvpow
 */
public class Ch6_3 {

  //Overloading 多載
   //方法名稱要一樣 傳入的參數類型或數量不一樣
    static float sum(float v1,float v2 ){
	return v1 + v2;
    }
    
    static String sum(String title,float v1,float v2){
	return title+":"+sum(v1,v2);
    }
    
    public static void main(String[] args) {
	System.out.println(sum(20,50));
	System.out.println(sum(20,50));
	System.out.println(sum("金額",20,50));
    }
    
}
