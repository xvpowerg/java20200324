/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200414;

/**
 *
 * @author xvpow
 */
public class Ch6_1 {
    static int[] cut(int[] array,int size){
	 if (array == null || array.length == 0){
	    System.out.println("錯誤的陣列!");
	    return new int[]{};
	} 
	if (size < 1 || size > array.length){
	    System.out.println("錯誤的參數!");
	     return new int[]{};
	}
	int[] result = new int[size];
	for (int i = 0; i < size;i++){
	    result[i] = array[i];
	}
	return result;
    }
    public static void main(String[] args) {
	     int[] array = {89,75,6,32,45,18,91};
	   
	    int[] newArray = cut(array,3);
	    for (int v : newArray){
		System.out.print(v+" ");
	    }
    }
}
