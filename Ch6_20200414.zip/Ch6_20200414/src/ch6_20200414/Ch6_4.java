/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200414;

public class Ch6_4 {
    
    // Overloading 規則
    //1 先找一模一樣類型
    //2 找相同類型可相容的 
    //3 找其他類型可相容的
    //4 轉成封箱類型
    
    static void test1(int v1){
	System.out.println("int");
    }
    static void test1(float v1){
	System.out.println("float");
    }
    
    static void test2(short v1){
	System.out.println("short");
    }
    static void test2(float v1){
	System.out.println("float");
    }
    
    static void test3(Integer v1){
	System.out.println("Integer");
    }
    static void test3(float v1){
	System.out.println("float");
    }
    static void test4(float v1,Integer v2){
        System.out.print("float Integer");
    }
    static void test4(Integer v1, long v2){
         System.out.print("Integer long");
    }

    public static void main(String[] args) {
	    // Overloading 規則
    //1 先找一模一樣類型
    //2 找相同類型可相容的 
    //3 找其他類型可相容的
    //4 轉成封箱類型
	//test1(10);
	//test2(5);//沒有小數點的數字預設為int 所以short不相容 
	test3(5);
	
    }
    
}
