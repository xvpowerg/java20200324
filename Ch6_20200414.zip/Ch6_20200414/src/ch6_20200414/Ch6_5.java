/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200414;

/**
 *
 * @author xvpow
 */
public class Ch6_5 {
       static void test1(int v1, float v2){
	    System.out.println("int float");
	}
        static void test1(int v1, int v2){
	    System.out.println("int int");
	}
	static void test2(int v1,float v2){
	    System.out.println("int float");
	}
	static void test2(int v1, Integer v2){
	    System.out.println("int Integer");
	}
	
	static void test3(float v1,Integer v2){
	    System.out.println("float Integer");
	}
	static void test3(Integer v1,float v2){
	    System.out.println("Integer float");
	}
    
	static void test4(float v1,Integer v2){
	    System.out.println("float Integer");
	}
	static void test4(Integer v1,long v2){
	    System.out.println("Integer long");
	}
	
	static void test5(int v1,float v2,Integer v3){
	    System.out.println("Integer float Integer");
	}
         static void test5(int v1,float v2,int v3){
	    System.out.println("int float int");
	}
	
	static void test6(int v1,float v2,Integer v3){
	    System.out.println("int float Integer");
	} 
	static void test6(long v1,Integer v2,Integer v3){
	    System.out.println("float Integer Integer");
	} 
         static void test7(int v1,float v2,Integer v3){
	    System.out.println("int float Integer");
	} 
	static void test7(float v1,int v2,Integer v3){
	    System.out.println("float int Integer");
	} 
    public static void main(String[] args) {
	    // Overloading 規則
    //1 先找一模一樣類型
    //2 找相同類型可相容的 
    //3 找其他類型可相容的
    //4 轉成封箱類型    
	//test1(2,6);	
	//test2(2,6);
	test3(2,6f);
	test4(2,6L);
	test5(1,2,3);
	//最後一個類型確定了 就比較前面兩組參數
	test6(1,2,Integer.valueOf(3));
	//以下會產生不知道該選誰
	//test7(1,2,Integer.valueOf(3));
	
    }
    
}
