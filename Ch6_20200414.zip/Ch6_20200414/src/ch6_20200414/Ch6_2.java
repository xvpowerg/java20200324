/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200414;

/**
 *
 * @author xvpow
 */
public class Ch6_2 {

   
    public static void main(String[] args) {
//	Integer value = null;
//	int value2 = value;//java.lang.NullPointerException
//	System.out.println(value2);
	
	//字串轉數字
	
	String v1 = "25";
	String v2 = "12";
	//字串轉數字
	//字串必須是完整的數字
	int n1 =  Integer.parseInt(v1);
	int n2 = Integer.parseInt(v2);
	System.out.println(v1 + v2);
	System.out.println(n1 + n2);

	//Boolean
	//只要不是true 不分大小寫 就回傳false
	boolean b1 = Boolean.parseBoolean("trUe");
	System.out.println(b1);
	
	//以下錯誤因為Integer 無法傳遞到 Float
//	Integer v3 = 10;
//	Float v4 = v3;
	//以下錯誤因為Integer 無法傳遞到 Float
//       int v5 = 25;
//      Float v6 = v5;
        Integer v7 = 25;
	float v6 = v7;
	
    }

    
}
