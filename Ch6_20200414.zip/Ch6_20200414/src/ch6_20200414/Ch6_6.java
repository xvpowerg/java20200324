/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200414;

/**
 *
 * @author xvpow
 */
public class Ch6_6 {

    
    public static void main(String[] args) {
	String values = "ABCDEFGHIJ";
	System.out.println(values.length());//取得字串長度
	System.out.println(values.charAt(2));//取得Index對應的字元
	   for (int i =0; i< values.length();i++){
	       System.out.println(values.charAt(i));
	   }
	   //字串本身不會被改變
	String newString =  values.concat("12345");
	System.out.println(newString);
	System.out.println(values);
    }
    
}
