/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch14_20200512;

/**
 *
 * @author xvpow
 */
public class MyLocation {
    private double lat = 12.567;
    private double lgt = 120.5678;
    private float speed = 10;
    
    public class Point{
	public double getLat(){
	    return lat;
	}
	public double getLgt(){
	    return lgt;
	}
     }
    
    public float getSpeed(){
	return speed;
    }
    
}
