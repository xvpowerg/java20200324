/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch14_20200512.lambda;

/**
 *
 * @author xvpow
 */
public class Ch14_3 {

    static void test1(Map map,int number ){
	String result = map.intMapToString(number);
	System.out.println(result);
    }
    
     static String intToCharString(Integer value){
	 char result = (char)value.intValue();
	 return String.valueOf(result);
     }   
    
    public static void main(String[] args) {
	   //Method Reference
   test1(Ch14_3::intToCharString,92);
	//能夠使用Lambda的一定是 Functional Interface
      //使用匿名內部類
    //我傳入一個整數 這個整數轉換成字元 回傳一個字串
  test1( new Map(){
     public String intMapToString(Integer value){
	 char result = (char)value.intValue();
	 return result+"";
     }
  } ,72);
  test1(i-> (char)i.intValue()+"", 98);
  //一個以上要加上小誇號
   test1((Integer i)->(char)i.intValue()+"", 72);
    //超過1行命令一定要加上大括號   
    //當加了{}如果方法有回傳值 就必須return   
   test1((Integer i) ->{ 
      return (char)i.intValue()+"";
   },85);

   
    }
}