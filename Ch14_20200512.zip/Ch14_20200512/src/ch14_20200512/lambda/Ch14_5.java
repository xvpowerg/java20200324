
package ch14_20200512.lambda;
import java.util.function.Supplier;
import java.util.Random;
public class Ch14_5 {
    static void lotto(Supplier<Integer> numberSupp,int[] arrays){
	for (int i =0;i<5;i++){
	   arrays[i] = numberSupp.get();
	}
    }
    public static void main(String[] args) {
	  Random random=  new Random();
	int[] array = new int[5];
	//因為沒有傳入任何參數所以要加上()	
	lotto(()->random.nextInt(70)+1,array);
	for (int v : array){
	    System.out.println(v);
	}
	
	int[] array2 = new int[5];
	lotto(()->random.nextInt(51)+50,array2);
    }
    
}
