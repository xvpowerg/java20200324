/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch14_20200512.lambda;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.UnaryOperator;
	

public class Ch14_4 {
    static int i = 0;
    static void appendValue(Consumer<String> consumer,
			   String... strs){
	for (String str : strs){
	    consumer.accept(str);
	}
    }
    
    public static void main(String[] args) {
      StringBuffer resultData = new StringBuffer();
      //將字串填入resultData
      appendValue(st->{resultData.append(st.toUpperCase());
		    resultData.append(" ");} ,
		    "Ken","Howard","Vivin");
      System.out.println(resultData.toString());
        
      //假設有一組長度為3的字串類型陣列
      //在 lambda內使用區域變數 此區域變數必須是常數
      String[] nameArray = new String[3];
      //錯誤的語法
      //appendValue(st->nameArray[i++] = st;,"Ken","Howard","Vivin");
      //appendValue(st->{nameArray[i++] = st},"Ken","Howard","Vivin");
      appendValue(st->nameArray[i++] = st,
		"Ken","Howard","Vivin");
      
      System.out.println(nameArray[1]);
    }
    
}
