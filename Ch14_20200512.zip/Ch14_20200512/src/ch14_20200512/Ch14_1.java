/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch14_20200512;

/**
 *
 * @author xvpow
 */
public class Ch14_1 {
    private String msg = "Hello!!";
    private int speed = 25;
      class Test2{
	  private int speed = 78;
	  public void printMsg(){
	      System.out.println(msg);
	  }
	  public void printSpeed(){
	      //內部類屬性名稱跟外部類屬性名稱相同 若要取得外部類的屬性 可用以下方式
	      System.out.println(Ch14_1.this.speed);
	  }
      }
       
    public static void main(String[] args) {
	Ch14_1.Test2 test2 = new Ch14_1().new Test2();
	test2.printMsg();
	test2.printSpeed();
    }
    
}
