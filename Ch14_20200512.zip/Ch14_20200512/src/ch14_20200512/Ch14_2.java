/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch14_20200512;

/**
 *
 * @author xvpow
 */
public class Ch14_2 {

    public static void main(String[] args) {
	MyLocation myLocation = new MyLocation();
	System.out.println(myLocation.getSpeed());
	//可透過內部類Point取得更多資訊
	MyLocation.Point point = myLocation.new Point();
	System.out.println(point.getLat()+":"+point.getLgt());
	
    }
    
}
