/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch19_20200528;
import java.util.TreeMap;
import java.util.Comparator;
/**
 *
 * @author xvpow
 */
public class Ch19_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	Student st1 = new Student("Ken",20);
	Student st2 = new Student("Vivin",59);
	Student st3 = new Student("Ken",83);
	Student st4 = new Student("Vivin",95);
	Student st5 = new Student("Vivin",72);
	Student st6 = new Student("Ken",67);
	Student[] stArray = {st1,st2,st3,st4,st5,st6};
	Comparator<Student> comp =
		Comparator.<Student,String>comparing(st->st.getName()).
			thenComparing(st->st.getScore());
	//Comparator 會覆蓋 Comparable
	TreeMap<Student,Integer> map = new TreeMap<>(comp);
	map.put(st1,st1.getName().length());
	map.put(st2,st2.getName().length());
	map.put(st3,st3.getName().length());
	map.put(st4,st4.getName().length());
	map.put(st5,st5.getName().length());
	System.out.println(map);
    }
    
}
