/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch19_20200528;

/**
 *
 * @author xvpow
 */
public class Ch19_7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	MyList myList = new MyList();
	myList.add("A");
	myList.add("B");
	myList.add("D");
	myList.add("C");
	myList.forEach(System.out::println);
	
	MyList<Integer> myList2 = new MyList<>();
	myList2.add(10);
	myList2.add(5);
	myList2.add(1);
	myList2.forEach(System.out::println);
    }
    
}
