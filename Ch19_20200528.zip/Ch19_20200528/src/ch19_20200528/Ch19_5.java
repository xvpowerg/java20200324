/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch19_20200528;
import java.util.TreeMap;

public class Ch19_5 {
    public static void main(String[] args) {
	//排序 排的是Key
	TreeMap<Integer,String> treeMap = new TreeMap<>();
	treeMap.put(5, "Ken");
	treeMap.put(2, "Vivin");
	treeMap.put(3, "Iris");
	treeMap.put(1, "Lucy");
	System.out.println(treeMap);
	
	
    }
    
}
