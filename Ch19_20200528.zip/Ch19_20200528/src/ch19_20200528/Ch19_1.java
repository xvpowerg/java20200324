/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch19_20200528;
import java.util.Map;
import java.util.Set;
import java.util.HashMap;
import java.util.function.BiConsumer;
public class Ch19_1 {
	static String key = "";
	static String value = "";
	static void forEach(BiConsumer bi){
	    bi.accept(key, value);
	}
    public static void main(String[] args) {
	Map<String,Integer> myMap = new HashMap<>();
	myMap.put("Ken", 25);
	myMap.put("Lindy", 31);
	myMap.put("Vivin", 73);
	myMap.put("Join", 94);
	
	System.out.println(myMap.get("Vivin"));
	
//	Set<String> keySet = myMap.keySet();
//	for (String key : keySet){
//	    System.out.println(myMap.get(key));
//	}
	myMap.forEach((key,value)->{
	    System.out.println(key+":"+value);
	});
	
	
    }
    
}
