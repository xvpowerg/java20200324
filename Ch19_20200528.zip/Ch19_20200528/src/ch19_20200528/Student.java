/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch19_20200528;

/**
 *
 * @author xvpow
 */
public class Student implements Comparable<Student> {
     private String name;
     private int score;
     
     public int compareTo(Student st){
	 if (score > st.getScore()){
	     return 1;
	 }else if(score < st.getScore()){
	      return -1;
	 }
	  return 0;
     }
     
     
     Student(String name,int score){
	 this.name = name;
	 this.score = score;
     }
     public String getName(){
	 return name;
     }
     public int getScore(){
	 return score;
     }
     public String toString(){
	 return this.getName()+":"+this.getScore();
     }
}
