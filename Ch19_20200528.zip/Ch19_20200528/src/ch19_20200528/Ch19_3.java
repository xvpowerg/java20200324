/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch19_20200528;
import java.util.Map;
import java.util.HashMap;
public class Ch19_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	Student st1 = new Student("Ken",20);
	Student st2 = new Student("Vivin",59);
	Student st3 = new Student("Ken",83);
	Student st4 = new Student("Vivin",95);
	Student st5 = new Student("Vivin",72);
	Student st6 = new Student("Ken",67);
	Student[] stArray = {st1,st2,st3,st4,st5,st6};
	Map<String,Integer> myMap = new HashMap<>();
	//希望幫我產生 一組Map 
	//Key 是姓名　valeu是 成績的總和
//	for (Student st : stArray ){
//	    String name = st.getName();
//	    int score = st.getScore();
//	    if (myMap.containsKey(name)){
//		score += myMap.get(name);
//	    }
//	    myMap.put(name, score);
//	}
//	for (Student st : stArray ){
//	    String key = st.getName();
//	    int score = st.getScore();
//	     myMap.computeIfPresent(key,(k,v)->v+score);
//	    myMap.computeIfAbsent(key, (k)->score);
//	}
//
    for (Student st : stArray ){
	    String key = st.getName();
	    int score = st.getScore();
	    myMap.merge(key, score, (o,n)->o+n);
	}

	System.out.println(myMap);
    }
    
}
