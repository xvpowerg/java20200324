/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch19_20200528;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author xvpow
 */
public class Ch19_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	Map<String,Integer> myMap = new HashMap<>();
	myMap.put("Ken", 25);
	myMap.put("Lindy", 31);
	myMap.put("Vivin", 73);
	myMap.put("Join", 94);
	myMap.put("Ken", 38);//Map key重複　value會覆蓋
	System.out.println(myMap);
	//containsKey 可判斷Key是否存在
	if (myMap.containsKey("Vivin") == false){
	    myMap.put("Vivin", 90);
	}
	
	
    }
    
}
