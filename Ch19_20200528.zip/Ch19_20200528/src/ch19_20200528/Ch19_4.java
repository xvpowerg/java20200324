/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch19_20200528;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author xvpow
 */
public class Ch19_4 {

    public static void main(String[] args) {
	Map<String,Integer> myMap = new HashMap<>();
	myMap.put("Ken", 25);
	myMap.put("Lindy", 31);
	myMap.put("Vivin", 73);
	myMap.put("Join", 94);
	
	myMap.merge("Vivin", 30,(ov,nv)->ov+nv);//key存在呼叫BiFunction 寫BIF的回傳值
	myMap.merge("Iris", 87,(ov,nv)->ov+nv);//Key不存在直接寫入新的ｖａｌｕｅ

	System.out.println(myMap);
	//key存在與否都會呼叫remappingFunction	
	//如果key不存在v為null
	myMap.compute("Join",(k,v)->{ 
	    System.out.println("k:"+k+" v:"+v);
	    return v + 20;
	});
	myMap.compute("Tom",(k,v)->{ 
	    System.out.println("k:"+k+" v:"+v);
	    return 32 ;
	});
	System.out.println(myMap);
	//IfAbsent key不存在才會做什麼
	//key不存在才put
	//myMap.putIfAbsent(key, Integer.MIN_VALUE)
	myMap.computeIfAbsent("Lucy",k->78);
	System.out.println(myMap);
	//IfPresent key存在才會做什麼
	myMap.computeIfPresent("Iris",(k,v)->{
	    System.out.println(k+":"+v);
	    return v+10;});
	System.out.println(myMap);
	
    }
    
}
