/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200409;

/**
 *
 * @author xvpow
 */
public class Ch5_6 {

    public static void main(String[] args) {
	//只有基本型態需要封箱
	//手動封箱 Boxing
	  //封箱類
	  //基     箱
	  //byte   Byte
	  //short Short
	  //int Integer
	  //long Long
	  //float Float
	  //double Double
	  //char Character
	  //boolean Boolean
	 Integer myInt =  Integer.valueOf(51);///手動封箱
	 Object ob = myInt;
	 System.out.println(ob);
	 //自動封箱
	 Integer myInt2 = 47;
	 
	//手動開箱 unBoxing
	int intValue = myInt.intValue();
	System.out.println(intValue);
	
	//自動開箱
	int intValue2 = myInt2;
	System.out.println(intValue2);
	//Integer.toOctalString(0) //10進位轉8進位字串
	//Integer.toBinaryString(0)//10進位轉2進位字串
	String hex = Integer.toHexString(1256);//10進位轉16進位字串
	System.out.println(hex);
    }
    
}
