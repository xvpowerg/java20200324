/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200409;

/**
 *
 * @author xvpow
 */
public class Ch5_2 {
    static void test3(int v){
	System.out.println(v);
    }
    public static void main(String[] args) {
	int y = 0;
	y++;
	test3(25);//記憶體中會記錄 main 在18行 跳到了test3
		//也會記錄這個方法的區域變數
	System.out.println(y);
        }
    
}
