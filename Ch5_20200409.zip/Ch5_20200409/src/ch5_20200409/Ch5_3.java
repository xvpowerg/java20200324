/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200409;

/**
 *
 * @author xvpow
 */
public class Ch5_3 {

	//call by value 適用於所有基本型態
	static void swap(int x,int y){
	    	//swap
		int tmp = x;
		x = y;
		y = tmp;
	}
       //call by reference
     static void swap(int[] array){
	 int tmp = array[0];
	array[0] = array[1];
	array[1] = tmp;
     }
    public static void main(String[] args) {
	//我傳進去方法的變數 是否會被改變
//	int x = 10;
//	int y = 25;
//	swap(x,y);
//	System.out.println(x+":"+y);
	int[] array = {79,81};
	swap(array);
	System.out.println(array[0]+":"+array[1]);
	
    }
    
}
