/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200409;

/**
 *
 * @author xvpow
 */
public class Ch5_4 {
    
    static void test1(int n){
	System.out.println("Start:"+n);
	if (n <= 3){
	  System.out.println(n);  
	  test1(n + 1);
	}
	System.out.println("End:"+n);
    }
    
    public static void main(String[] args) {
	test1(1);
    }
    
}
