/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200409;

/**
 *
 * @author xvpow
 */
public class Ch5_5 {
    //vargs 當我一個方法的參數不清楚要傳入多少筆數值時
    static int sum(int... values){
	int ans = 0;
	for (int v : values){
	    ans += v;
	}
	    return ans;
    }
     //vargs 只能是方法的最後一個參數
    static float dot(float v1,int... v2 ){
	    float ans = 0;
	    for (int v: v2){
		ans+= v1 * v; 
	    }
	return ans;    
    }
    public static void main(String... args) {
	
	int value = sum(5,8,2,5,7,1);
	System.out.println(value);
	    value = sum();
	System.out.println(value);
	
	float dotAns =  dot(2.5f,1,2,3);
	System.out.println(dotAns);
    }
    
}
