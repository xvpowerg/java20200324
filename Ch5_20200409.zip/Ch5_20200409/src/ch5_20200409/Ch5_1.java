/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200409;

/**
 *
 * @author xvpow
 */
public class Ch5_1 {
    //Method
    //必要條件
    //回傳類型 方法名稱 傳入參數 方法本體
      static void test1(){
	  System.out.println("Test!!");
      }
      static int add(int a,int b){
	  int ans = a + b;
	  //return 作用
	  //回傳數值
	  //離開方法
	  return ans;
      }
     //靜態的方法 或其它靜態表達式 他只能呼叫靜態的
       // 靜態只能呼叫靜態
    public static void main(String[] args) {
	//1 可減少重複程式碼
	//2 可以幫助我們了解程式架構
	//專家說~約有20多行的程式碼時 就可考慮拆分成多個方法
	test1();
	int v1 = add(5,2);
	System.out.println(v1);
    }
    
}
