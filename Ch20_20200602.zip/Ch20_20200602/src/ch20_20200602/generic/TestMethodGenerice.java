/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch20_20200602.generic;
import java.util.function.UnaryOperator;
import java.util.function.Function;
public class TestMethodGenerice {
    public <T> T method1(T v,
	    UnaryOperator<T> un){
	return un.apply(v);
    }
    
    public static int sum(String st,
	    Function<String,Integer> f){
	return f.apply(st);
    }
    //public static<T,R> 宣告泛型這不可寫? xxxx
     public static<T,R> R sum(T st,Function<T,R> f){
	return f.apply(st);
    }
}
