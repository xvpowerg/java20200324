/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch20_20200602.generic;
import java.util.ArrayList;
import java.util.Comparator;
public class Ch20_1 {
    
    static void method1(ArrayList<Test1> list){	
    }
    //不寫泛型什麼都可傳
   static void method2(ArrayList list){       
    }
   //泛型類型是Test2或Test2子類型 都可作為傳入參數List的泛型類型
   //只可以讀取不可寫入(唯讀)
   static void method3(ArrayList<? extends Test2> list){
       //Test2 t3 = list.get(0);
      for (Test2 t2 : list){
      }
      //list.add(new Test2());
   }
   //? super 表示為Test2的父類型泛型或Test2都可傳入
   //可讀可寫
   static void method4(ArrayList<? super Test2> list){
	  //讀取必須是Object類型
          Object t2 = list.get(1);
	  //寫入為Test2類型
	  list.add(new Test2());
   }
    public static void main(String[] args) {
	 Test1 t1 = new Test2();
	 ArrayList<Test2> list2 = new ArrayList<>();
	 //泛型類型一般情況下必須一樣 下面是錯誤的
	//method1(list2);
	 ArrayList<Test1> list3 = new ArrayList<>();
	 list3.add(new Test2());
	 method1(list3);
	 
	     //不寫泛型什麼都可傳
	 ArrayList<System> list4 = new ArrayList<>();
	 method2(list4);
	 //子類或自己可傳入
	 ArrayList<Test2> list5 = new ArrayList<>();
	 method3(list5);
	 ArrayList<Test3> list6 = new ArrayList<>();
	  method3(list6);
	 ArrayList<Test1> list7 = new ArrayList<>();
	 // method3(list7);
	  ArrayList<Test1> list8 = new ArrayList<>();
	 method4(list8);
//	 ArrayList<Test5> list9 = new ArrayList<>();
//	  method4(list9);
	 
    }
    
}
