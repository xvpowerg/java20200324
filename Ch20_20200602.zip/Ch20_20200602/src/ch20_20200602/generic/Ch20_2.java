/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch20_20200602.generic;
import java.util.ArrayList;
/**
 *
 * @author xvpow
 */
public class Ch20_2 {
      public static void main(String[] args) {
	  TestMethodGenerice tmg1 = new  TestMethodGenerice();
	  String str = tmg1.method1("Ken",(s)->s.toUpperCase());
	  System.out.println(str);
	  int number = tmg1.method1(10, (s)->s+20);
	  System.out.println(number);
	  float number2 = tmg1.<Float>method1(2.5f, (s)->s+17);
	  System.out.println(number2);
	  
	int strSum =   TestMethodGenerice.sum("ABC", v->{
	      int sum = 0;	     
	      for (int i =0;i<v.length();i++){
		 char c1 =  v.charAt(i);
		 sum += c1;
	      }
	      return sum;
	  });
	System.out.println(strSum);
	
	ArrayList<Integer> list = new ArrayList<>();
	list.add(10);
	list.add(20);
	list.add(60);
	int sum2 = TestMethodGenerice.sum(list,ls->{
	    int sum = 0;
	    for (int v :list){
		sum += v;
	    }
           return sum;
	} );
	
	System.out.println(sum2);
      }
}

