/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch20_20200602.stream;
import java.util.stream.Stream;
import java.util.stream.IntStream;
import java.util.stream.LongStream;
import java.util.stream.DoubleStream;
import java.util.Random;
public class Ch20_3 {
    public static void main(String[] args) {
	// TODO code application logic here
	Stream<String> strStream =  Stream.of("A","B","C","D");
	strStream.skip(2).forEach(System.out::println);
	
	// 如果沒加上limit會無限產生
	Stream<Integer> intStream = Stream.generate(()->new Random().nextInt(1000));
	intStream.limit(5).forEach(System.out::println);
	// 如果沒加上limit會無限產生
	Stream<Integer> intSream2 =  Stream.iterate(1, v->v+1);
	intSream2.limit(10).forEach(System.out::println);
	
	System.out.println("=================================");
	IntStream myIntStr = IntStream.range(0, 10);
	myIntStr.forEach(System.out::println);
	System.out.println("=================================");
	 myIntStr = IntStream.rangeClosed(1, 10);
	 myIntStr.forEach(System.out::println);
    }
}
