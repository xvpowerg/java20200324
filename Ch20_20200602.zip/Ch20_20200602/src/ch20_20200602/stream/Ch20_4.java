/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch20_20200602.stream;
import java.util.ArrayList;
import java.util.stream.Stream;
public class Ch20_4 {
    
  
    public static void main(String[] args) {
	//Stream特性
	//不可變動性(Immutability)
	//惰性 lazy 與 終端 terminal
	//不可重複使用
	ArrayList<String> nameList = new ArrayList<>(); 
	nameList.add("Ken");
	nameList.add("Vivin");
	nameList.add("Lindy");
	nameList.add("Join");
	nameList.forEach(s->System.out.print(s+" "));
	System.out.println();
	//不可變動性(Immutability)
 	Stream<String> nameStream = nameList.stream();
	nameStream.filter(n->n.length()>4).forEach(s->System.out.print(s+" "));
	System.out.println();
	System.out.println("nameList Size:"+nameList.size());
	//會錯誤因為nameStream不可重複使用
	nameStream.filter(n->n.indexOf("n") > -1).forEach(System.out::println);
    }
    
}

