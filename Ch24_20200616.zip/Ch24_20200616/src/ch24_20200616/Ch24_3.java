/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch24_20200616;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
public class Ch24_3 {
    public static void main(String[] args) {
	    File file = new File("c:\\myDir\\User.obj");
	    User user = new User("qwer","12345","Ken","0911888333");
	    Order o1 = new Order();
	    o1.setOrderName("超好吃肉粽");
	    user.setOrder(o1);
	    try(FileOutputStream fout = new FileOutputStream(file);
		ObjectOutputStream objout = new ObjectOutputStream(fout)){
		objout.writeObject(user);
	    }catch(IOException ex){
		System.out.println(ex);
	    }
    }
}
