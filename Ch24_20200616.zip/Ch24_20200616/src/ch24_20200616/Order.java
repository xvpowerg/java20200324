/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch24_20200616;

/**
 *
 * @author xvpow
 */
public class Order {
    private String orderName;

    public String getOrderName() {
	return orderName;
    }

    public void setOrderName(String orderName) {
	this.orderName = orderName;
    }

    @Override
    public String toString() {
	return "Order{" + "orderName=" + orderName + '}';
    }
    
}
