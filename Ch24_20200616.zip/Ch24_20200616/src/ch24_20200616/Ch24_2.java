/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch24_20200616;
import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
public class Ch24_2 {
   //反序列化
   //某種檔案格式轉換為物件
    public static void main(String[] args) {
	File file = new File("c:\\myDir\\Object.data");
	try(FileInputStream fIn = new FileInputStream(file);
	     ObjectInputStream objin = new ObjectInputStream(fIn);){
	    String myMsg = (String)objin.readObject();
	    System.out.println(myMsg);
	}catch(FileNotFoundException | ClassNotFoundException ex){
	    System.out.println(ex);
	}catch(IOException ex){
	    System.out.println(ex);
	}
	
	
    }
    
}
