/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch24_20200616;

/**
 *
 * @author xvpow
 */
public class Person {
    private String name;
    private String tel;
    Person(){
	
    }
    public Person(String name, String tel) {
	this.name = name;
	this.tel = tel;
    }

    public String getName() {
	return name;
    }

    public void setName(String name) {
	this.name = name;
    }

    public String getTel() {
	return tel;
    }

    public void setTel(String tel) {
	this.tel = tel;
    }
    
    
}
