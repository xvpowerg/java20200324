/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch24_20200616;
import java.nio.file.Path;
import java.nio.file.Paths;
public class Ch24_5 {
    public static void main(String[] args) {
	//Path  有不可修改性 沒有方法會修改自己
	Path path = 
		Paths.get("c:", "myDir","test1","msg.txt");
	System.out.println(path);
	System.out.println(path.getName(2));
	System.out.println(path.getRoot());
	Path path2 = 
		Paths.get("c", "myDir","test1","msg.txt");
        System.out.println(path2.getName(2));
	System.out.println(path2.getRoot());
	
	 Path myFileDir = Paths.get("c:", "myFile");
	 Path jsonPath =  Paths.get("json","save.json");
	 Path newPath = 
		 myFileDir.resolve(jsonPath);
	 System.out.println(newPath);
	
	 Path myFileDir2 = Paths.get("c:", "myFile");
	 Path jsonPath2 =  Paths.get("d:","save.json");
	Path newPath2 = 
		 myFileDir2.resolve(jsonPath2);
	System.out.println(newPath2);
	
	 Path myPath3 = Paths.get("c:", "/home/./test1");
	   Path newPath3 = myPath3.normalize();
	 System.out.println(newPath3);
	  Path myPath4 = Paths.get("c:", "/home/test1/test2/../seting");
	   Path newPath4 = myPath4.normalize();
	  System.out.println(newPath4);
	  
	  Path myPath5 = Paths.get("c:","A","B","C","D");
	  Path newPath5 =   myPath5.subpath(0, 3);
	  System.out.println(newPath5);
	  
	 Path myPath6 = Paths.get("x","A","B","C","D");
	  Path newPath6 =   myPath6.subpath(0, 3);
	  System.out.println(newPath6);
	  
	   Path myPath7 = Paths.get("C:","A","B");//目前目錄
	   Path myPath8 = Paths.get("C:","A","B","C","D");//我想要去的目錄
	   Path relatPath =  myPath7.relativize(myPath8);//相對路徑是什麼
	   System.out.println(relatPath);
	   
	    Path myPath9 = Paths.get("D:","A","B");//目前目錄
	   Path myPath10 = Paths.get("C:","A","B","C","D");//我想要去的目錄
	   //relativize 只能是相同根目錄 不然會拋出例外.IllegalArgumentException: 'other' has different root
	   Path relatPath2 =  myPath9.relativize(myPath10);//相對路徑是什麼
	   System.out.println(relatPath2);
	   
    }
    
}
