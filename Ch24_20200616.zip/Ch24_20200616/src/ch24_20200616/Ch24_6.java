/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch24_20200616;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.io.IOException;
import java.nio.file.StandardCopyOption;
public class Ch24_6 {

    
    public static void main(String[] args) {
	Path src = Paths.get("C:", "MyDir","test.zip");
	Path target = Paths.get("C:", "MyDir","test_copy.zip");
	Path movTarget = Paths.get("C:", "MyDir","dir1","test_move.zip");
	try{
	    //預設情況下如果target已存在 copy時會拋出例外
	    //不可搭配ATOMIC_MOVE
//	    Files.copy(src,target,
//		    StandardCopyOption.REPLACE_EXISTING);	

	    //move 就是檔案　
	    //檔copy到目標目錄　
	    //在delete來源檔
	    //不可使用tandardCopyOption.COPY_ATTRIBUTES
	     //預設情況下如果target已存在 move時會拋出例外
	    Files.move(src, movTarget, StandardCopyOption.REPLACE_EXISTING);
	}catch(IOException ex){
	    System.out.println(ex);
	}
    }
    
}
