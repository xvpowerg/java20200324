/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch24_20200616;
import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
public class Ch24_4 {

//如果父類別沒有 implements Serializable 必須提供預設建構子
//不然無法反序列化
    public static void main(String[] args) {
	 File file = new File("c:\\myDir\\User.obj");
	 try(FileInputStream fin = new FileInputStream(file);
		ObjectInputStream objIn = new ObjectInputStream(fin); ){
		 User user = (User) objIn.readObject();
		 System.out.println(user);
	 }catch(IOException | ClassNotFoundException ex){
	     System.out.println(ex);
	 }
    }
    
}
